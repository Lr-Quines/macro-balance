﻿using MacroBalanceRN.MacroBalance;
using MacroBalanceWS.Models;
using Swashbuckle.Swagger.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Http;
using System.Web.Http.Description;

namespace MacroBalanceWS.Controllers
{
    // Rota da API
    [RoutePrefix("api/AlimentoSessao")]
    public class AlimentoSessaoController : ApiController
    {

        #region Public Methods

        #region Create

        [Route("CreateAlimentoSessaoRecord")]
        [HttpGet]
        [ResponseType(typeof(ReturnErrorModel))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult CreateAlimentoSessaoRecord(
                [FromUri] string alimentoId,
                [FromUri] string sessaoAlimentarId,
                [FromUri] decimal dose
            )
        {
            ReturnErrorModel ret = new ReturnErrorModel
            {
                Error = false,
                ErrorMessage = string.Empty
            };

            try
            {
                AlimentoSessaoRN alimentoSessaoRN = new AlimentoSessaoRN();

                alimentoSessaoRN.CreateAlimentoSessaoRecord(alimentoId, sessaoAlimentarId, dose);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        #endregion Create

        #region Delete

        [Route("DeleteAlimentoSessaoRecordById")]
        [HttpGet]
        [ResponseType(typeof(ReturnErrorModel))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult DeleteAlimentoSessaoRecordById(
                [FromUri] string alimentoSessaoId
            )
        {
            ReturnErrorModel ret = new ReturnErrorModel
            {
                Error = false,
                ErrorMessage = string.Empty
            };

            try
            {
                AlimentoSessaoRN alimentoSessaoRN = new AlimentoSessaoRN();

                alimentoSessaoRN.DeleteAlimentoSessaoRecordById(alimentoSessaoId);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        #endregion Delete

        #endregion Public Methods

    }
}