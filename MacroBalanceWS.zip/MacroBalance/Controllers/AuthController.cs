﻿using System;
using System.Net;
using System.Web.Http;
using System.Web.Http.Description;
using MacroBalanceRN.MacroBalance;
using MacroBalanceRN.Models;
using MacroBalanceWS.Auth.Models;
using Swashbuckle.Swagger.Annotations;

namespace MacroBalance.Controllers
{
    // Rota da API
    [RoutePrefix("api/Auth")]
    public class AuthController : ApiController
    {

        #region Public Methods

        #region Get

        [Route("SignIn")]
        [HttpPost]
        [ResponseType(typeof(RetSignIn))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult SignIn(
                [FromBody] string password,
                [FromUri] string usernameEmail
            )
        {
            RetSignIn ret = new RetSignIn
            {
                Error = false,
                ErrorMessage = string.Empty,
                Data = false,
                UserId = string.Empty,
                Username = string.Empty,
                Token = string.Empty
            };

            try
            {
                AuthRN authRN = new AuthRN();

                authRN.SignIn(password, usernameEmail, out bool isSuccess, out string userId, out string username);

                if (isSuccess) // Se o LOGIN foi um sucesso...
                {
                    ret.Data = true;
                    ret.UserId = userId;
                    ret.Username = username;

                    ret.Token = authRN.GetToken(username);
                }

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        [Route("SignUp")]
        [HttpPost]
        [ResponseType(typeof(RetSignUp))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult SignUp(
                [FromBody] User user
            )
        {
            RetSignUp ret = new RetSignUp
            {
                Error = false,
                ErrorMessage = string.Empty,
                Data = string.Empty,
                Token = string.Empty
            };

            try
            {
                AuthRN authRN = new AuthRN();

                ret.Data = authRN.SignUp(user);
                ret.Token = authRN.GetToken(user.Username);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        [Route("ValidateSignUp")]
        [HttpGet]
        [ResponseType(typeof(RetValidadeSignUp))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult ValidateSignUp(
                [FromUri] string username,
                [FromUri] string email
            )
        {
            RetValidadeSignUp ret = new RetValidadeSignUp
            {
                Error = false,
                ErrorMessage = string.Empty,
                Data = true,
                EmailExists = true
            };

            try
            {
                AuthRN authRN = new AuthRN();

                ret.Data = authRN.UsernameExists(username);
                ret.EmailExists = authRN.EmailExists(email);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        #endregion Get

        #endregion Public Methods

    }

}
