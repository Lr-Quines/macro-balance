﻿using System;
using System.Net;
using System.Web.Http;
using System.Web.Http.Description;
using MacroBalanceRN.MacroBalance;
using MacroBalanceRN.Models;
using MacroBalanceWS.Models;
using MacroBalanceWS.Models.UnidadeMedida;
using Swashbuckle.Swagger.Annotations;

namespace MacroBalance.Controllers
{
    // Rota da API
    [RoutePrefix("api/UnidadeMedida")]
    public class UnidadeMedidaController : ApiController
    {

        #region Public Methods

        #region Get

        [Route("ValidateUnidadeMedida")]
        [HttpPost]
        [ResponseType(typeof(RetValidateUnidadeMedida))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult ValidateUnidadeMedida(
                [FromBody] UnidadeMedida record
            )
        {
            RetValidateUnidadeMedida ret = new RetValidateUnidadeMedida
            {
                Error = false,
                ErrorMessage = string.Empty,
                Data = true,
                SimboloExists = true
            };

            try
            {
                UnidadeMedidaRN unidadeMedidaRN = new UnidadeMedidaRN();

                ret.Data = unidadeMedidaRN.NomeExists(record.Nome, record.UsuarioCriador);
                ret.SimboloExists = unidadeMedidaRN.SimboloExists(record.Simbolo, record.UsuarioCriador);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        #endregion Get

        #region Create

        [Route("CreateUnidadeMedidaRecord")]
        [HttpPost]
        [ResponseType(typeof(RetId))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult CreateUnidadeMedidaRecord(
                [FromBody] UnidadeMedida record
            )
        {
            RetId ret = new RetId
            {
                Error = false,
                ErrorMessage = string.Empty,
                Data = string.Empty
            };

            try
            {
                UnidadeMedidaRN unidadeMedidaRN = new UnidadeMedidaRN();

                ret.Data = unidadeMedidaRN.CreateUnidadeMedidaRecord(record);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        #endregion Create

        #endregion Public Methods

    }

}
