﻿using MacroBalanceRN.MacroBalance;
using MacroBalanceWS.Models;
using Swashbuckle.Swagger.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Http;
using System.Web.Http.Description;

namespace MacroBalanceWS.Controllers
{
    // Rota da API
    [RoutePrefix("api/SessaoAlimentar")]
    public class SessaoAlimentarController : ApiController
    {

        #region Public Methods

        #region Get

        [Route("GetSessaoAlimentarRecordById")]
        [HttpGet]
        [ResponseType(typeof(RetId))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult GetSessaoAlimentarRecordById(
                [FromUri] string sessaoAlimentarId
            )
        {
            RetId ret = new RetId
            {
                Error = false,
                ErrorMessage = string.Empty,
                Data = string.Empty
            };

            try
            {
                SessaoAlimentarRN sessaoAlimentarRN = new SessaoAlimentarRN();

                ret.Data = sessaoAlimentarRN.GetSessaoAlimentarRecordById(sessaoAlimentarId);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        #endregion Get

        #region Create

        [Route("CreateSessaoAlimentarRecord")]
        [HttpGet]
        [ResponseType(typeof(ReturnErrorModel))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult CreateSessaoAlimentarRecord(
                [FromUri] string nome,
                [FromUri] string planoAlimentarId
            )
        {
            ReturnErrorModel ret = new ReturnErrorModel
            {
                Error = false,
                ErrorMessage = string.Empty
            };

            try
            {
                SessaoAlimentarRN sessaoAlimentarRN = new SessaoAlimentarRN();

                sessaoAlimentarRN.CreateSessaoAlimentarRecord(nome, planoAlimentarId);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        #endregion Create

        #region Update

        [Route("UpdateSessaoAlimentarRecordById")]
        [HttpGet]
        [ResponseType(typeof(ReturnErrorModel))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult UpdateSessaoAlimentarRecordById(
                [FromUri] string nome,
                [FromUri] string sessaoAlimentarId
            )
        {
            ReturnErrorModel ret = new ReturnErrorModel
            {
                Error = false,
                ErrorMessage = string.Empty
            };

            try
            {
                SessaoAlimentarRN sessaoAlimentarRN = new SessaoAlimentarRN();

                sessaoAlimentarRN.UpdateSessaoAlimentarRecordById(nome, sessaoAlimentarId);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        #endregion Update

        #region Delete

        [Route("DeleteSessaoAlimentarRecordById")]
        [HttpGet]
        [ResponseType(typeof(ReturnErrorModel))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult DeleteSessaoAlimentarRecordById(
                [FromUri] string sessaoAlimentarId
            )
        {
            ReturnErrorModel ret = new ReturnErrorModel
            {
                Error = false,
                ErrorMessage = string.Empty
            };

            try
            {
                SessaoAlimentarRN sessaoAlimentarRN = new SessaoAlimentarRN();

                sessaoAlimentarRN.DeleteSessaoAlimentarRecordById(sessaoAlimentarId);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        #endregion Delete

        #endregion Public Methods

    }
}