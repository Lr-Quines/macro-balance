﻿using MacroBalanceRN.MacroBalance;
using MacroBalanceRN.Models;
using MacroBalanceWS.Models;
using Swashbuckle.Swagger.Annotations;
using System;
using System.Collections.Generic;
using System.Net;
using System.Web.Http;
using System.Web.Http.Description;

namespace MacroBalanceWS.Controllers
{
    // Rota da API
    [RoutePrefix("api/PlanoAlimentar")]
    public class PlanoAlimentarController : ApiController
    {

        #region Public Methods

        #region Get

        [Route("ValidatePlanoAlimentar")]
        [HttpGet]
        [ResponseType(typeof(RetValidatePlanoAlimentar))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult ValidatePlanoAlimentar(
                [FromUri] string nome,
                [FromUri] string userId,
                [FromUri] string planoAlimentarId
            )
        {
            RetValidatePlanoAlimentar ret = new RetValidatePlanoAlimentar
            {
                Error = false,
                ErrorMessage = string.Empty,
                Data = true
            };

            try
            {
                PlanoAlimentarRN planoAlimentarRN = new PlanoAlimentarRN();

                ret.Data = planoAlimentarRN.NomeExists(nome, userId, planoAlimentarId);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        [Route("PreparationPlanoAlimentarList")]
        [HttpGet]
        [ResponseType(typeof(RetPlanoAlimentarList))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult PreparationPlanoAlimentarList(
                [FromUri] string userId
            )
        {
            RetPlanoAlimentarList ret = new RetPlanoAlimentarList
            {
                Error = false,
                ErrorMessage = string.Empty,
                Data = new List<PlanoAlimentar>()
            };

            try
            {
                PlanoAlimentarRN planoAlimentarRN = new PlanoAlimentarRN();

                ret.Data = planoAlimentarRN.GetPlanoAlimentarList(userId);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        [Route("GetPlanoAlimentarRecordById")]
        [HttpGet]
        [ResponseType(typeof(RetPlanoAlimentar))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult GetPlanoAlimentarRecordById(
                [FromUri] string planoAlimentarId
            )
        {
            RetPlanoAlimentar ret = new RetPlanoAlimentar
            {
                Error = false,
                ErrorMessage = string.Empty,
                Data = new PlanoAlimentar()
            };

            try
            {
                PlanoAlimentarRN planoAlimentarRN = new PlanoAlimentarRN();

                ret.Data = planoAlimentarRN.GetPlanoAlimentarRecordById(planoAlimentarId);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        [Route("GetPlanoSessaoAlimentarById")]
        [HttpGet]
        [ResponseType(typeof(RetPlanoAlimentar))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult GetPlanoSessaoAlimentarById(
                [FromUri] string planoAlimentarId
            )
        {
            RetPlanoAlimentar ret = new RetPlanoAlimentar
            {
                Error = false,
                ErrorMessage = string.Empty,
                Data = new PlanoAlimentar()
            };

            try
            {
                PlanoAlimentarRN planoAlimentarRN = new PlanoAlimentarRN();

                ret.Data = planoAlimentarRN.GetPlanoSessaoAlimentarById(planoAlimentarId);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        #endregion Get

        #region Create

        [Route("CreatePlanoAlimentarRecord")]
        [HttpPost]
        [ResponseType(typeof(RetId))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult CreatePlanoAlimentarRecord(
                [FromBody] PlanoAlimentar record
            )
        {
            RetId ret = new RetId
            {
                Error = false,
                ErrorMessage = string.Empty,
                Data = string.Empty
            };

            try
            {
                PlanoAlimentarRN planoAlimentarRN = new PlanoAlimentarRN();

                ret.Data = planoAlimentarRN.CreatePlanoAlimentarRecord(record);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        #endregion Create

        #region Update

        [Route("UpdatePlanoAlimentarRecordById")]
        [HttpPost]
        [ResponseType(typeof(ReturnErrorModel))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult UpdatePlanoAlimentarRecordById(
                [FromBody] PlanoAlimentar record
            )
        {
            ReturnErrorModel ret = new ReturnErrorModel
            {
                Error = false,
                ErrorMessage = string.Empty
            };

            try
            {
                PlanoAlimentarRN planoAlimentarRN = new PlanoAlimentarRN();

                planoAlimentarRN.UpdatePlanoAlimentarRecordById(record);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        #endregion Update

        #region Delete

        [Route("DeletePlanoAlimentarRecord")]
        [HttpGet]
        [ResponseType(typeof(ReturnErrorModel))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult DeletePlanoAlimentarRecord(
                [FromUri] string planoAlimentarId
            )
        {
            ReturnErrorModel ret = new ReturnErrorModel
            {
                Error = false,
                ErrorMessage = string.Empty
            };

            try
            {
                PlanoAlimentarRN planoAlimentarRN = new PlanoAlimentarRN();

                planoAlimentarRN.DeletePlanoAlimentarRecord(planoAlimentarId);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        #endregion Delete

        #endregion Public Methods

    }
}