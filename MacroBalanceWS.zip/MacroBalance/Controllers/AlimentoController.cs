﻿using MacroBalanceRN.MacroBalance;
using MacroBalanceRN.Models;
using MacroBalanceWS.Models;
using Swashbuckle.Swagger.Annotations;
using System;
using System.Collections.Generic;
using System.Net;
using System.Web.Http;
using System.Web.Http.Description;

namespace MacroBalanceWS.Controllers
{
    // Rota da API
    [RoutePrefix("api/Alimento")]
    public class AlimentoController : ApiController
    {

        #region Public Methods

        #region Get

        [Route("PreparationAlimentoList")]
        [HttpGet]
        [ResponseType(typeof(RetPreparationAlimentoList))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult PreparationAlimentoList(
                [FromUri] string userId
            )
        {
            RetPreparationAlimentoList ret = new RetPreparationAlimentoList
            {
                Error = false,
                ErrorMessage = string.Empty,
                Data = new List<Alimento>()
            };

            try
            {
                AlimentoRN alimentoRN = new AlimentoRN();

                ret.Data = alimentoRN.GetAlimentoList(userId);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        [Route("PreparationAlimentoForm")]
        [HttpGet]
        [ResponseType(typeof(RetPreparationAlimentoForm))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult PreparationAlimentoForm(
                [FromUri] string userId,
                [FromUri] string alimentoId
            )
        {
            RetPreparationAlimentoForm ret = new RetPreparationAlimentoForm
            {
                Error = false,
                ErrorMessage = string.Empty,
                Data = new List<Combobox>()
            };

            try
            {
                AlimentoRN alimentoRN = new AlimentoRN();

                ret.Data = alimentoRN.GetUnidadeMedidaCombobox(userId);
                if (!(alimentoId is null)) if (alimentoId.Length > 0) ret.Alimento = alimentoRN.GetAlimentoRecordById(alimentoId);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        #endregion Get

        #region Create

        [Route("CreateAlimentoRecord")]
        [HttpPost]
        [ResponseType(typeof(ReturnErrorModel))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult CreateAlimentoRecord(
                [FromBody] Alimento record
            )
        {
            ReturnErrorModel ret = new ReturnErrorModel
            {
                Error = false,
                ErrorMessage = string.Empty
            };

            try
            {
                AlimentoRN alimentoRN = new AlimentoRN();

                alimentoRN.CreateAlimentoRecord(record);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        #endregion Create

        #region Update

        [Route("UpdateAlimentoRecord")]
        [HttpPost]
        [ResponseType(typeof(ReturnErrorModel))]
        [SwaggerResponse(HttpStatusCode.OK, "Execução com sucesso.")]
        [SwaggerResponse(HttpStatusCode.BadRequest, "Erro de parâmetros.")]
        [SwaggerResponse(HttpStatusCode.InternalServerError, "Erro de servidor.")]
        public IHttpActionResult UpdateAlimentoRecord(
                [FromBody] Alimento record
            )
        {
            ReturnErrorModel ret = new ReturnErrorModel
            {
                Error = false,
                ErrorMessage = string.Empty
            };

            try
            {
                AlimentoRN alimentoRN = new AlimentoRN();

                alimentoRN.UpdateAlimentoRecord(record);

                return Ok(ret);
            }
            catch (Exception ex)
            {
                ret.Error = true;
                ret.ErrorMessage = ex.Message;

                Console.WriteLine($"Erro: {ex.Message}");

                return Content(HttpStatusCode.OK, ret);
            }
        }

        #endregion Update

        #endregion Public Methods

    }
}