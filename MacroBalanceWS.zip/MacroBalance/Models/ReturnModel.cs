﻿using System.Runtime.Serialization;

namespace MacroBalanceWS.Models
{
    [DataContract]
    public abstract class ReturnModel<T> : IReturnModel
    {
        [DataMember]
        virtual public T Data { get; set; }

        [DataMember]
        public virtual bool Error { get; set; }

        [DataMember]
        public virtual string ErrorMessage { get; set; }
    }
}