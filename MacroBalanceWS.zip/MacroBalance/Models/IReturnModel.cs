﻿namespace MacroBalanceWS.Models
{
    public interface IReturnModel
    {
        bool Error { get; set; }

        string ErrorMessage { get; set; }
    }
}