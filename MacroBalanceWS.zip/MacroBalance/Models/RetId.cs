﻿using System.Runtime.Serialization;

namespace MacroBalanceWS.Models
{
    [DataContract]
    public class RetId : ReturnModel<string>
    {
        [DataMember(Name = "Id")]
        public override string Data { get; set; }
    }
}