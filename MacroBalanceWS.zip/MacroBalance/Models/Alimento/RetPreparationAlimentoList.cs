﻿using System.Collections.Generic;
using System.Runtime.Serialization;
using MacroBalanceRN.Models;

namespace MacroBalanceWS.Models
{
    [DataContract]
    public class RetPreparationAlimentoList : ReturnModel<List<Alimento>>
    {
        [DataMember(Name = "AlimentoList")]
        public override List<Alimento> Data { get; set; }
    }
}