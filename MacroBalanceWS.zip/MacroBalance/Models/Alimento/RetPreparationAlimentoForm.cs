﻿using System.Collections.Generic;
using System.Runtime.Serialization;

using MacroBalanceRN.Models;

namespace MacroBalanceWS.Models
{
    [DataContract]
    public class RetPreparationAlimentoForm : ReturnModel<List<Combobox>>
    {
        [DataMember(Name = "UnidadeMedidaCombobox")]
        public override List<Combobox> Data { get; set; }

        [DataMember]
        public Alimento Alimento { get; set; }
    }
}