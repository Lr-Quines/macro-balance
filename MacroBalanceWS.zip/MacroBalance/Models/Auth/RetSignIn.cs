﻿using MacroBalanceWS.Models;
using System.Runtime.Serialization;

namespace MacroBalanceWS.Auth.Models
{
    [DataContract]
    public class RetSignIn : ReturnModel<bool>
    {
        [DataMember(Name = "IsSuccess")]
        public override bool Data { get; set; }

        [DataMember]
        public string UserId { get; set; }

        [DataMember]
        public string Username { get; set; }

        [DataMember]
        public string Token { get; set; }
    }
}