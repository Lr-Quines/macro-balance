﻿using MacroBalanceWS.Models;
using System.Runtime.Serialization;

namespace MacroBalanceWS.Auth.Models
{
    [DataContract]
    public class RetSignUp : ReturnModel<string>
    {
        [DataMember(Name = "UserId")]
        public override string Data { get; set; }

        [DataMember]
        public string Token { get; set; }
    }
}