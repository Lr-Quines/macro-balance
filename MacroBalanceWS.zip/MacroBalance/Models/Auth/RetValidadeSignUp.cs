﻿using MacroBalanceWS.Models;
using System.Runtime.Serialization;

namespace MacroBalanceWS.Auth.Models
{
    [DataContract]
    public class RetValidadeSignUp : ReturnModel<bool>
    {
        [DataMember(Name = "UsernameExists")]
        public override bool Data { get; set; }

        [DataMember]
        public bool EmailExists { get; set; }
    }
}