﻿using System.Runtime.Serialization;

namespace MacroBalanceWS.Models
{
    [DataContract]
    public class ReturnErrorModel : ReturnModel<object>
    {
        [DataMember]
        public override object Data { get; set; }
    }
}