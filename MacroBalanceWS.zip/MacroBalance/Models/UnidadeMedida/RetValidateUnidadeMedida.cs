﻿using System.Runtime.Serialization;

namespace MacroBalanceWS.Models.UnidadeMedida
{
    [DataContract]
    public class RetValidateUnidadeMedida : ReturnModel<bool>
    {
        [DataMember(Name = "NomeExists")]
        public override bool Data { get; set; }

        [DataMember]
        public bool SimboloExists { get; set; }
    }
}