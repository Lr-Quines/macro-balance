﻿using System.Runtime.Serialization;

using MacroBalanceRN.Models;

namespace MacroBalanceWS.Models
{
    [DataContract]
    public class RetPlanoAlimentar : ReturnModel<PlanoAlimentar>
    {
        [DataMember(Name = "PlanoAlimentar")]
        public override PlanoAlimentar Data { get; set; }
    }
}