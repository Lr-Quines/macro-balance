﻿using System.Runtime.Serialization;

namespace MacroBalanceWS.Models
{
    [DataContract]
    public class RetValidatePlanoAlimentar : ReturnModel<bool>
    {
        [DataMember(Name = "NomeExists")]
        public override bool Data { get; set; }
    }
}