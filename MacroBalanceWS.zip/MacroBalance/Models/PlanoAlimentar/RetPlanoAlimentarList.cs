﻿using System.Collections.Generic;
using System.Runtime.Serialization;

using MacroBalanceRN.Models;

namespace MacroBalanceWS.Models
{
    [DataContract]
    public class RetPlanoAlimentarList : ReturnModel<List<PlanoAlimentar>>
    {
        [DataMember(Name = "PlanoAlimentarList")]
        public override List<PlanoAlimentar> Data { get; set; }
    }
}