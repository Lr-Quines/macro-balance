import { Component } from '@angular/core';
import { ElementSideMenu } from './models/element-side-menu';
import { Router } from '@angular/router';

@Component({
  selector: 'mb-side-menu',
  templateUrl: './side-menu.component.html',
  styleUrl: './side-menu.component.scss'
})
export class SideMenuComponent {

  constructor(
    private _router: Router
  ) {
    this.setIsSelected();
  }


  // #region ==========> PROPERTIES <==========
  protected opened: { value: boolean } = { value: false };

  protected elementSideMenuList: ElementSideMenu[] = [
    { Title: 'Planos alimentares', Url: 'planos-alimentares', Icon: 'food_bank', IsSelected: false },
    { Title: 'Meus alimentos', Url: 'meus-alimentos', Icon: 'local_dining', IsSelected: false }
  ];
  // #endregion ==========> PROPERTIES <==========


  // #region ==========> UTILITIES <==========
  public changeIsSelected(elementSideMenu: ElementSideMenu): void {
    this.elementSideMenuList.find(e => e.IsSelected)!.IsSelected = false;
    elementSideMenu.IsSelected = true;
  }

  private setIsSelected(): void {
    if (this._router.url.includes('planos-alimentares')) this.elementSideMenuList.find(e => e.Title === 'Planos alimentares')!.IsSelected = true;
    if (this._router.url.includes('meus-alimentos')) this.elementSideMenuList.find(e => e.Title === 'Meus alimentos')!.IsSelected = true;
  }
  // #endregion ==========> UTILITIES <==========


}
