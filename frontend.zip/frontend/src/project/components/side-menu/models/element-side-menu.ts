export class ElementSideMenu {
  public Title: string = '';
  public Url: string = '';
  public Icon: string = '';
  public IsSelected: boolean = false;
}
