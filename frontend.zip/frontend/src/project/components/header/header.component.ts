import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'mb-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent {

  constructor(
    private _router: Router
  ) { }


  // #region ==========> PROPERTIES <==========

  // #region PUBLIC
  @Input({ required: true }) public opened: { value: boolean } = { value: false };
  // #endregion PUBLIC

  // #endregion ==========> PROPERTIES <==========


  // #region ==========> UTILITIES <==========
  protected signOut(): void {
    localStorage.removeItem('username');
    localStorage.removeItem('userid');
    localStorage.removeItem('token');

    this._router.navigate(['/login']);
  }

  protected get title(): string {
    if (this._router.url.includes('planos-alimentares')) return ' - Planos alimentares';
    if (this._router.url.includes('meus-alimentos')) return ' - Meus alimentos';
    else return '';
  }
  // #endregion ==========> UTILITIES <==========


}
