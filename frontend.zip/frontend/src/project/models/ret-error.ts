export class RetError {
  public Error: boolean = true;
  public ErrorMessage: string = 'Ocorreu um erro...';
}
