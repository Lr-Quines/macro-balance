import { RetError } from "./ret-error";

export class RetId extends RetError {
  public Id: string = '';
}
