export class Combobox {
  public Id: string = '';
  public Label: string = '';
}
