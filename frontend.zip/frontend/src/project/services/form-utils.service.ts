import { Injectable } from '@angular/core';
import { AbstractControl, FormGroup } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class FormUtilsService {

  static validateFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(field => {
      const CONTROL: AbstractControl<any, any> | null = formGroup.get(field);

      CONTROL?.markAsDirty();
      CONTROL?.markAsTouched();
    });
  }

}
