import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthStorageService {


  // #region ==========> UTILITIES <==========
  public get userId(): string {
    return localStorage.getItem('userid')!;
  }
  // #endregion ==========> UTILITIES <==========


}
