import { Component, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UnidadeMedidaService } from './services/unidade-medida.service';
import { UnidadeMedida } from './models/unidade-medida';
import { AuthStorageService } from '../../services/auth-storage.service';
import { RetValidateUnidadeMedida } from './models/ret-validate-unidade-medida';
import { MatSnackBar } from '@angular/material/snack-bar';
import { RetId } from '../../models/ret-id';
import { MatDialogRef } from '@angular/material/dialog';
import { FormUtilsService } from '../../services/form-utils.service';

@Component({
  selector: 'mb-dialog-adicionar-unidade-medida',
  templateUrl: './dialog-adicionar-unidade-medida.component.html',
  styleUrl: './dialog-adicionar-unidade-medida.component.scss'
})
export class DialogAdicionarUnidadeMedidaComponent {

  constructor(
    private _formBuilder: FormBuilder,
    private _unidadeMedidaService: UnidadeMedidaService,
    private _authStorageService: AuthStorageService,
    private _matDialogRef: MatDialogRef<DialogAdicionarUnidadeMedidaComponent>,
    private _matSnackBar: MatSnackBar
  ) {
    this.createBaseForm();
  }


  // #region ==========> PROPERTIES <==========

  // #region PRIVATE
  private _unidadeMedida: UnidadeMedida = new UnidadeMedida();

  @Output('newUnidadeMedida') private readonly _EMIT_NEW_UNIDADE_MEDIDA: EventEmitter<UnidadeMedida> = new EventEmitter<UnidadeMedida>();
  // #endregion PRIVATE

  // #region PROTECTED
  // #endregion PROTECTED

  // #region PUBLIC
  // #endregion PUBLIC

  // #endregion ==========> PROPERTIES <==========


  // #region ==========> FORM BUILDER <==========
  protected form!: FormGroup;

  // #region FORM DATA
  private get nome(): string { return this.form.get('nome')?.value; }
  private get simbolo(): string { return this.form.get('simbolo')?.value; }
  // #endregion FORM DATA

  // #region FORM VALIDATORS
  private createBaseForm(): void {
    this.form = this._formBuilder.group({
      nome: ['', Validators.required],
      simbolo: ['', Validators.required]
    });
  }
  // #endregion FORM VALIDATORS

  // #endregion ==========> FORM BUILDER <==========


  // #region ==========> SERVICE METHODS <==========

  // #region GET
  protected validateUnidadeMedida(): void {
    this.assignValues();

    this._unidadeMedidaService.validateUnidadeMedida(this._unidadeMedida).subscribe({
      next: (response: RetValidateUnidadeMedida) => this.validate(response.NomeExists, response.SimboloExists),
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error}`, 'X')
    });
  }
  // #endregion GET

  // #region CREATE
  private createUnidadeMedidaRecord(): void {
    this._unidadeMedidaService.createUnidadeMedidaRecord(this._unidadeMedida).subscribe({
      next: (response: RetId) => {
        this._unidadeMedida.Id = response.Id;
        this._matSnackBar.open(`Unidade de medida "${this._unidadeMedida.Nome}" cadastrada com sucesso!`, 'X', { duration: 3500 });
        this._matDialogRef.close();
        this._EMIT_NEW_UNIDADE_MEDIDA.emit(this._unidadeMedida);
      },
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error}`, 'X')
    });
  }
  // #endregion CREATE

  // #endregion ==========> SERVICE METHODS <==========


  // #region ==========> UTILITIES <==========
  private assignValues(): void {
    this._unidadeMedida = {
      Id: '',
      Nome: this.nome,
      Simbolo: this.simbolo,
      UsuarioCriador: this._authStorageService.userId
    };
  }

  private validate(nomeExists: boolean, simboloExists: boolean): void {
    if (this.form.invalid) FormUtilsService.validateFields(this.form);

    if (nomeExists && simboloExists) this._matSnackBar.open(`Unidade de medida '${this.nome}' e símbolo '${this.simbolo}' já cadastrados`, 'X');
    else if (nomeExists) this._matSnackBar.open(`Unidade de medida '${this.nome}' já cadastrada`, 'X');
    else if (simboloExists) this._matSnackBar.open(`Símbolo '${this.simbolo}' já cadastrado`, 'X');
    else if (this.form.valid) this.createUnidadeMedidaRecord();
  }
  // #endregion ==========> UTILITIES <==========


}
