export class UnidadeMedida {
  public Id: string = '';
  public Nome: string = '';
  public Simbolo: string = '';
  public UsuarioCriador: string = '';
}
