import { RetError } from "../../../models/ret-error";

export class RetValidateUnidadeMedida extends RetError {
  public NomeExists: boolean = true;
  public SimboloExists: boolean = true;
}
