import { Injectable } from '@angular/core';
import { RetError } from '../../../models/ret-error';
import { Observable, take, tap } from 'rxjs';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { RetValidateUnidadeMedida } from '../models/ret-validate-unidade-medida';
import { UnidadeMedida } from '../models/unidade-medida';
import { RetId } from '../../../models/ret-id';

@Injectable({
  providedIn: 'root'
})
export class UnidadeMedidaService {

  constructor(
    private httpClient: HttpClient
  ) { }


  // #region ==========> PROPERTIES <==========
  private readonly _BASE_URL: string = `http://localhost:44384/api/UnidadeMedida`;
  private readonly _HTTP_HEADERS: HttpHeaders = new HttpHeaders().set('Content-Type', 'application/json');
  // #endregion ==========> PROPERTIES <==========


  // #region ==========> SERVICE METHODS <==========

  // #region GET
  public validateUnidadeMedida(record: UnidadeMedida): Observable<RetValidateUnidadeMedida> {
    const URL: string = `${this._BASE_URL}/ValidateUnidadeMedida`;

    return this.httpClient.post<RetValidateUnidadeMedida>(URL, record, { headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetValidateUnidadeMedida) => this.showErrorMessage(response)));
  }
  // #endregion GET

  // #region CREATE
  public createUnidadeMedidaRecord(record: UnidadeMedida): Observable<RetId> {
    const URL: string = `${this._BASE_URL}/CreateUnidadeMedidaRecord`;

    return this.httpClient.post<RetId>(URL, record, { headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetId) => this.showErrorMessage(response)));
  }
  // #endregion CREATE

  // #endregion ==========> SERVICE METHODS <==========


  // #region ==========> UTILITIES <==========
  private showErrorMessage(response: RetError): void { if (response.Error) throw Error(response.ErrorMessage); }
  // #endregion ==========> UTILITIES <==========


}
