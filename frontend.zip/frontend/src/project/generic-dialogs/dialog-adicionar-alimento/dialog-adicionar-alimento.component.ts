import { Component, EventEmitter, Input, OnInit, Output, TemplateRef } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { UnidadeMedida } from '../dialog-adicionar-unidade-medida/models/unidade-medida';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AlimentoService } from './services/alimento.service';
import { AuthStorageService } from '../../services/auth-storage.service';
import { RetPreparationAlimentoForm } from './models/ret-preparation-alimento-form';
import { Combobox } from '../../models/combobox';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Alimento } from './models/alimento';
import { FormUtilsService } from '../../services/form-utils.service';

@Component({
  selector: 'mb-dialog-adicionar-alimento',
  templateUrl: './dialog-adicionar-alimento.component.html',
  styleUrl: './dialog-adicionar-alimento.component.scss'
})
export class DialogAdicionarAlimentoComponent implements OnInit {

  constructor(
    private _matDialog: MatDialog,
    private _matSnackBar: MatSnackBar,
    private _alimentoService: AlimentoService,
    private _authStorageService: AuthStorageService,
    private _formBuilder: FormBuilder,
    private _matDialogRef: MatDialogRef<DialogAdicionarAlimentoComponent>,
  ) {
    this.createBaseForm();
  }

  public ngOnInit(): void {
    if (this.alimentoId) if (this.alimentoId.length > 0) this.isEditingMode = true;
    this.preparationAlimentoForm();
  }


  // #region ==========> PROPERTIES <==========

  // #region PRIVATE
  @Output('updateList') private readonly _EMIT_UPDATE_LIST: EventEmitter<void> = new EventEmitter<void>();
  // #endregion PRIVATE

  // #region PROTECTED
  protected unidadeMedidaCombobox: Combobox[] = [];

  protected isEditingMode: boolean = false;
  // #endregion PROTECTED

  // #region PUBLIC
  @Input({ required: true }) public alimentoId: string = '';
  // #endregion PUBLIC

  // #endregion ==========> PROPERTIES <==========


  // #region ==========> FORM BUILDER <==========
  protected form!: FormGroup;

  // #region GETTERS
  private get nome(): string { return this.form.get('nome')?.value.trim(); }
  private get marca(): string { return this.form.get('marca')?.value.trim(); }
  private get caloria(): number { return this.form.get('caloria')?.value; }
  private get carboidrato(): number { return this.form.get('carboidrato')?.value; }
  private get proteina(): number { return this.form.get('proteina')?.value; }
  private get gordura(): number { return this.form.get('gordura')?.value; }
  private get dose(): number { return this.form.get('dose')?.value; }
  private get unidadeMedida(): string { return this.form.get('unidadeMedida')?.value; }
  // #endregion GETTERS

  // #region SETTERS
  private set nome(value: string) { this.form.get('nome')?.setValue(value); }
  private set marca(value: string) { this.form.get('marca')?.setValue(value); }
  private set caloria(value: number) { this.form.get('caloria')?.setValue(value); }
  private set carboidrato(value: number) { this.form.get('carboidrato')?.setValue(value); }
  private set proteina(value: number) { this.form.get('proteina')?.setValue(value); }
  private set gordura(value: number) { this.form.get('gordura')?.setValue(value); }
  private set dose(value: number) { this.form.get('dose')?.setValue(value); }
  private set unidadeMedida(value: string) { this.form.get('unidadeMedida')?.setValue(value); }
  // #endregion SETTERS

  // #region FORM VALIDATORS
  private createBaseForm(): void {
    this.form = this._formBuilder.group({
      nome: ['', Validators.required],
      marca: '',
      caloria: ['', [Validators.required, Validators.min(0)]],
      carboidrato: ['', [Validators.required, Validators.min(0)]],
      proteina: ['', [Validators.required, Validators.min(0)]],
      gordura: ['', [Validators.required, Validators.min(0)]],
      dose: ['', [Validators.required, Validators.min(1)]],
      unidadeMedida: ['', Validators.required]
    });
  }
  // #endregion FORM VALIDATORS

  // #endregion ==========> FORM BUILDER <==========


  // #region ==========> SERVICE METHODS <==========

  // #region GET
  private preparationAlimentoForm(): void {
    this._alimentoService.preparationAlimentoForm(this._authStorageService.userId, this.alimentoId).subscribe({
      next: (response: RetPreparationAlimentoForm) => {
        this.unidadeMedidaCombobox = response.UnidadeMedidaCombobox;
        if (this.isEditingMode) this.patchBaseForm(response.Alimento);
      },
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error.message}`, 'X')
    });
  }
  // #endregion GET

  // #region CREATE
  protected createAlimentoRecord(): void {
    if (this.form.invalid) { FormUtilsService.validateFields(this.form); return; }

    const RECORD: Alimento = this.assignValues();

    this._alimentoService.createAlimentoRecord(RECORD).subscribe({
      next: () => {
        this._matSnackBar.open(`Alimento "${RECORD.Nome}" cadastrado com sucesso!`, 'X', { duration: 3500 });
        this._matDialogRef.close();
        this._EMIT_UPDATE_LIST.emit();
      },
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error.message}`, 'X')
    });
  }
  // #endregion CREATE

  // #region UPDATE
  protected updateAlimentoRecord(): void {
    if (this.form.invalid) { FormUtilsService.validateFields(this.form); return; }

    const RECORD: Alimento = this.assignValues();

    this._alimentoService.updateAlimentoRecord(RECORD).subscribe({
      next: () => {
        this._matSnackBar.open(`Alimento "${RECORD.Nome}" atualizado com sucesso!`, 'X', { duration: 3500 });
        this._matDialogRef.close();
        this._EMIT_UPDATE_LIST.emit();
      },
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error.message}`, 'X')
    });
  }
  // #endregion UPDATE

  // #endregion ==========> SERVICE METHODS <==========


  // #region ==========> UTILITIES <==========
  protected openDialogAdicionarUnidadeMedida(dialog: TemplateRef<any>): void {
    this._matDialog.open(dialog, {
      width: '350px'
    });
  }

  private assignValues(): Alimento {
    return {
      Id: this.alimentoId,
      Nome: this.nome,
      Marca: this.marca,
      Caloria: this.caloria,
      Carboidrato: this.carboidrato,
      Proteina: this.proteina,
      Gordura: this.gordura,
      Dose: this.dose,
      UnidadeMedida: this.unidadeMedida,
      UsuarioCriador: this._authStorageService.userId
    };
  }

  private patchBaseForm(record: Alimento): void {
    this.nome = record.Nome;
    this.marca = record.Marca;
    this.caloria = record.Caloria;
    this.carboidrato = record.Carboidrato;
    this.proteina = record.Proteina;
    this.gordura = record.Gordura;
    this.dose = record.Dose;
    this.unidadeMedida = record.UnidadeMedida;
  }

  protected handleUnidadeMedida(newUnidadeMedida: UnidadeMedida) {
    this.unidadeMedidaCombobox.push({ Id: newUnidadeMedida.Id, Label: `${newUnidadeMedida.Nome} (${newUnidadeMedida.Simbolo})` });
    this.unidadeMedidaCombobox.sort((a, b) => a.Label.localeCompare(b.Label));
    this.unidadeMedida = newUnidadeMedida.Id;
  }
  // #endregion ==========> UTILITIES <==========


}
