import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, take, tap } from 'rxjs';
import { RetError } from '../../../models/ret-error';
import { RetPreparationAlimentoForm } from '../models/ret-preparation-alimento-form';
import { Alimento } from '../models/alimento';

@Injectable({
  providedIn: 'root'
})
export class AlimentoService {

  constructor(
    private httpClient: HttpClient
  ) { }


  // #region ==========> PROPERTIES <==========
  private readonly _BASE_URL: string = `http://localhost:44384/api/Alimento`;
  private readonly _HTTP_HEADERS: HttpHeaders = new HttpHeaders().set('Content-Type', 'application/json');
  // #endregion ==========> PROPERTIES <==========


  // #region ==========> SERVICE METHODS <==========

  // #region GET
  public preparationAlimentoForm(userId: string, alimentoId: string): Observable<RetPreparationAlimentoForm> {
    const HTTP_PARAMS: HttpParams = new HttpParams()
      .set('userId', userId)
      .set('alimentoId', alimentoId);

    const URL: string = `${this._BASE_URL}/PreparationAlimentoForm`;

    return this.httpClient.get<RetPreparationAlimentoForm>(URL, { params: HTTP_PARAMS, headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetPreparationAlimentoForm) => this.showErrorMessage(response)));
  }
  // #endregion GET

  // #region CREATE
  public createAlimentoRecord(record: Alimento): Observable<RetError> {
    const URL: string = `${this._BASE_URL}/CreateAlimentoRecord`;

    return this.httpClient.post<RetError>(URL, record, { headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetError) => this.showErrorMessage(response)));
  }
  // #endregion CREATE

  // #region UPDATE
  public updateAlimentoRecord(record: Alimento): Observable<RetError> {
    const URL: string = `${this._BASE_URL}/UpdateAlimentoRecord`;

    return this.httpClient.post<RetError>(URL, record, { headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetError) => this.showErrorMessage(response)));
  }
  // #endregion UPDATE

  // #endregion ==========> SERVICE METHODS <==========


  // #region ==========> UTILITIES <==========
  private showErrorMessage(response: RetError): void { if (response.Error) throw Error(response.ErrorMessage); }
  // #endregion ==========> UTILITIES <==========


}
