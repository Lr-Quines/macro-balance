import { Combobox } from "../../../models/combobox";
import { RetError } from "../../../models/ret-error";
import { Alimento } from "./alimento";

export class RetPreparationAlimentoForm extends RetError {
  public UnidadeMedidaCombobox: Combobox[] = [];
  public Alimento: Alimento = new Alimento();
}
