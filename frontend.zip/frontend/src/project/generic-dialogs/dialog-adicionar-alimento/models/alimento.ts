export class Alimento {
  public Id?: string = '';
  public Nome: string = '';
  public Marca: string = '';
  public Caloria: number = 0;
  public Carboidrato: number = 0;
  public Proteina: number = 0;
  public Gordura: number = 0;
  public UnidadeMedida: string = '';
  public Dose: number = 0;
  public UsuarioCriador: string = '';
}
