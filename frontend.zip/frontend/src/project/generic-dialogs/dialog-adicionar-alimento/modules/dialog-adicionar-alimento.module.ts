import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogModule } from '@angular/material/dialog';
import {  DialogAdicionarAlimentoComponent } from '../dialog-adicionar-alimento.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltipModule } from '@angular/material/tooltip';
import { DialogAdicionarUnidadeMedidaModule } from '../../dialog-adicionar-unidade-medida/modules/dialog-adicionar-unidade-medida.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    DialogAdicionarAlimentoComponent
  ],
  imports: [
    CommonModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatSelectModule,
    MatTooltipModule,
    DialogAdicionarUnidadeMedidaModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [
    DialogAdicionarAlimentoComponent
  ]
})
export class AdicionarAlimentoModule { }
