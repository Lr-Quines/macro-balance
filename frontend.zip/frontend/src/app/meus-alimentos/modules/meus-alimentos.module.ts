import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatTableModule } from '@angular/material/table';

import { MeusAlimentosRoutingModule } from './meus-alimentos-routing.module';
import { MeusAlimentosComponent } from '../meus-alimentos.component';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { AdicionarAlimentoModule } from '../../../project/generic-dialogs/dialog-adicionar-alimento/modules/dialog-adicionar-alimento.module';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';


@NgModule({
  declarations: [
    MeusAlimentosComponent
  ],
  imports: [
    CommonModule,
    MeusAlimentosRoutingModule,
    MatTableModule,
    MatIconModule,
    MatButtonModule,
    AdicionarAlimentoModule,
    MatTooltipModule,
    MatProgressSpinnerModule
  ]
})
export class MeusAlimentosModule { }
