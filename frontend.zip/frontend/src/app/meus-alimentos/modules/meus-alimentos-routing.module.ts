import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MeusAlimentosComponent } from '../meus-alimentos.component';

const routes: Routes = [
  { path: '', component: MeusAlimentosComponent, data: { title: 'Meus alimentos' } }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MeusAlimentosRoutingModule { }
