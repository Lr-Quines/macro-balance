export class Alimento {
  Id: string = '';
  Nome: string = '';
  Marca: string = '';
  Caloria: number = 0;
  Gordura: number = 0;
  Proteina: number = 0;
  Carboidrato: number = 0;
  UnidadeMedida: string = '';
  Dose: number = 0;
  UsuarioCriador: string = '';
}
