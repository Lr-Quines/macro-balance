import { RetError } from "../../../project/models/ret-error";
import { Alimento } from "./alimento";

export class RetPreparationAlimentoList extends RetError {
  public AlimentoList: Alimento[] = [];
}
