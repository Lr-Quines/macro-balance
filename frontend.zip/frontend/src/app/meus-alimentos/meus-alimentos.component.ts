import { Component, OnInit, TemplateRef } from '@angular/core';
import { Alimento } from './models/alimento';
import { MatDialog } from '@angular/material/dialog';
import { AlimentoService } from './services/alimento.service';
import { AuthStorageService } from '../../project/services/auth-storage.service';
import { RetPreparationAlimentoList } from './models/ret-preparation-alimento-list';
import { MatSnackBar } from '@angular/material/snack-bar';

export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}

@Component({
  selector: 'mb-meus-alimentos',
  templateUrl: './meus-alimentos.component.html',
  styleUrl: './meus-alimentos.component.scss'
})
export class MeusAlimentosComponent implements OnInit {

  constructor(
    private _matDialog: MatDialog,
    private _alimentoService: AlimentoService,
    private _authStorageService: AuthStorageService,
    private _matSnackBar: MatSnackBar
  ) { }

  public ngOnInit(): void {
    this.preparationAlimentoList();
  }


  // #region ==========> PROPERTIES <==========

  // #region PROTECTED
  protected displayedColumns: string[] = ['Nome', 'Caloria', 'Carboidrato', 'Gordura', 'Proteina', 'Dose', 'Acoes'];

  protected alimentoList: Alimento[] = [];

  protected isLoaginPage: boolean = true;
  // #endregion PROTECTED

  // #endregion ==========> PROPERTIES <==========


  // #region ==========> SERVICE METHODS <==========

  // #region GET
  protected preparationAlimentoList(): void {
    this.isLoaginPage = true;
    this._alimentoService.preparationAlimentoList(this._authStorageService.userId).subscribe({
      next: (response: RetPreparationAlimentoList) => {
        this.alimentoList = response.AlimentoList;
        this.isLoaginPage = false;
      },
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error.message}`, 'X')
    });
  }
  // #endregion GET

  // #endregion ==========> SERVICE METHODS <==========


  // #region ==========> UTILITIES <==========
  protected openDialogAdicionarAlimento(dialog: TemplateRef<any>): void {
    this._matDialog.open(dialog, {
      width: '1000px'
    });
  }
  // #endregion ==========> UTILITIES <==========


}
