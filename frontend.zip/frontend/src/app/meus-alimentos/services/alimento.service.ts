import { Injectable } from '@angular/core';
import { RetError } from '../../../project/models/ret-error';
import { Observable, take, tap } from 'rxjs';
import { RetPreparationAlimentoList } from '../models/ret-preparation-alimento-list';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AlimentoService {

  constructor(
    private httpClient: HttpClient
  ) { }


  // #region ==========> PROPERTIES <==========
  private readonly _BASE_URL: string = `http://localhost:44384/api/Alimento`;
  private readonly _HTTP_HEADERS: HttpHeaders = new HttpHeaders().set('Content-Type', 'application/json');
  // #endregion ==========> PROPERTIES <==========


  // #region ==========> SERVICE METHODS <==========

  // #region GET
  public preparationAlimentoList(userId: string): Observable<RetPreparationAlimentoList> {
    const HTTP_PARAMS: HttpParams = new HttpParams()
      .set('userId', userId);

    const URL: string = `${this._BASE_URL}/PreparationAlimentoList`;

    return this.httpClient.get<RetPreparationAlimentoList>(URL, { params: HTTP_PARAMS, headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetPreparationAlimentoList) => this.showErrorMessage(response)));
  }
  // #endregion GET

  // #endregion ==========> SERVICE METHODS <==========


  // #region ==========> UTILITIES <==========
  private showErrorMessage(response: RetError): void { if (response.Error) throw Error(response.ErrorMessage); }
  // #endregion ==========> UTILITIES <==========


}
