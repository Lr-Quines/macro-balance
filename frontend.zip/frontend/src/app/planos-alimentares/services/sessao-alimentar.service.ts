import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, take, tap } from 'rxjs';
import { RetError } from '../../../project/models/ret-error';
import { RetId } from '../../../project/models/ret-id';

@Injectable({
  providedIn: 'root'
})
export class SessaoAlimentarService {

  constructor(
    private httpClient: HttpClient
  ) { }


  // #region ==========> PROPERTIES <==========
  private readonly _BASE_URL: string = `http://localhost:44384/api/SessaoAlimentar`;
  private readonly _HTTP_HEADERS: HttpHeaders = new HttpHeaders().set('Content-Type', 'application/json');
  // #endregion ==========> PROPERTIES <==========


  // #region ==========> SERVICE METHODS <==========

  // #region GET
  public getSessaoAlimentarRecordById(sessaoAlimentarId: string): Observable<RetId> {
    const HTTP_PARAMS: HttpParams = new HttpParams()
      .set('sessaoAlimentarId', sessaoAlimentarId);

    const URL: string = `${this._BASE_URL}/GetSessaoAlimentarRecordById`;

    return this.httpClient.get<RetId>(URL, { params: HTTP_PARAMS, headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetId) => this.showErrorMessage(response)));
  }
  // #endregion GET

  // #region CREATE
  public createSessaoAlimentarRecord(nome: string, planoAlimentarId: string): Observable<RetError> {
    const HTTP_PARAMS: HttpParams = new HttpParams()
      .set('nome', nome)
      .set('planoAlimentarId', planoAlimentarId);

    const URL: string = `${this._BASE_URL}/CreateSessaoAlimentarRecord`;

    return this.httpClient.get<RetError>(URL, { params: HTTP_PARAMS, headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetError) => this.showErrorMessage(response)));
  }
  // #endregion CREATE

  // #region UPDATE
  public updateSessaoAlimentarRecordById(nome: string, sessaoAlimentarId: string): Observable<RetError> {
    const HTTP_PARAMS: HttpParams = new HttpParams()
      .set('nome', nome)
      .set('sessaoAlimentarId', sessaoAlimentarId);

    const URL: string = `${this._BASE_URL}/UpdateSessaoAlimentarRecordById`;

    return this.httpClient.get<RetError>(URL, { params: HTTP_PARAMS, headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetError) => this.showErrorMessage(response)));
  }
  // #endregion UPDATE

  // #region DELETE
  public deleteSessaoAlimentarRecordById(sessaoAlimentarId: string): Observable<RetError> {
    const HTTP_PARAMS: HttpParams = new HttpParams()
      .set('sessaoAlimentarId', sessaoAlimentarId);

    const URL: string = `${this._BASE_URL}/DeleteSessaoAlimentarRecordById`;

    return this.httpClient.get<RetError>(URL, { params: HTTP_PARAMS, headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetError) => this.showErrorMessage(response)));
  }
  // #endregion DELETE

  // #endregion ==========> SERVICE METHODS <==========


  // #region ==========> UTILITIES <==========
  private showErrorMessage(response: RetError): void { if (response.Error) throw Error(response.ErrorMessage); }
  // #endregion ==========> UTILITIES <==========

}
