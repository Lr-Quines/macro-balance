import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RetError } from '../../../project/models/ret-error';
import { Observable, tap, take } from 'rxjs';
import { PlanoAlimentar } from '../models/plano-alimentar';
import { RetId } from '../../../project/models/ret-id';
import { RetValidatePlanoAlimentar } from '../models/ret-validate-plano-alimentar';
import { RetPlanoAlimentarList } from '../models/ret-plano-alimentar-list';
import { RetPlanoAlimentar } from '../models/ret-plano-alimentar';

@Injectable({
  providedIn: 'root'
})
export class PlanosAlimentaresService {

  constructor(
    private httpClient: HttpClient
  ) { }


  // #region ==========> PROPERTIES <==========
  private readonly _BASE_URL: string = `http://localhost:44384/api/PlanoAlimentar`;
  private readonly _HTTP_HEADERS: HttpHeaders = new HttpHeaders().set('Content-Type', 'application/json');
  // #endregion ==========> PROPERTIES <==========


  // #region ==========> SERVICE METHODS <==========

  // #region GET
  public validatePlanoAlimentar(nome: string, userId: string, planoAlimentarId: string): Observable<RetValidatePlanoAlimentar> {
    const HTTP_PARAMS: HttpParams = new HttpParams()
      .set('nome', nome)
      .set('userId', userId)
      .set('planoAlimentarId', planoAlimentarId);

    const URL: string = `${this._BASE_URL}/ValidatePlanoAlimentar`;

    return this.httpClient.get<RetValidatePlanoAlimentar>(URL, { params: HTTP_PARAMS, headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetValidatePlanoAlimentar) => this.showErrorMessage(response)));
  }

  public preparationPlanoAlimentarList(userId: string): Observable<RetPlanoAlimentarList> {
    const HTTP_PARAMS: HttpParams = new HttpParams()
      .set('userId', userId);

    const URL: string = `${this._BASE_URL}/PreparationPlanoAlimentarList`;

    return this.httpClient.get<RetPlanoAlimentarList>(URL, { params: HTTP_PARAMS, headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetPlanoAlimentarList) => this.showErrorMessage(response)));
  }

  public getPlanoAlimentarRecordById(planoAlimentarId: string): Observable<RetPlanoAlimentar> {
    const HTTP_PARAMS: HttpParams = new HttpParams()
      .set('planoAlimentarId', planoAlimentarId);

    const URL: string = `${this._BASE_URL}/GetPlanoAlimentarRecordById`;

    return this.httpClient.get<RetPlanoAlimentar>(URL, { params: HTTP_PARAMS, headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetPlanoAlimentar) => this.showErrorMessage(response)));
  }

  public getPlanoSessaoAlimentarById(planoAlimentarId: string): Observable<RetPlanoAlimentar> {
    const HTTP_PARAMS: HttpParams = new HttpParams()
      .set('planoAlimentarId', planoAlimentarId);

    const URL: string = `${this._BASE_URL}/GetPlanoSessaoAlimentarById`;

    return this.httpClient.get<RetPlanoAlimentar>(URL, { params: HTTP_PARAMS, headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetPlanoAlimentar) => this.showErrorMessage(response)));
  }
  // #endregion GET

  // #region CREATE
  public createPlanoAlimentarRecord(record: PlanoAlimentar): Observable<RetId> {
    const URL: string = `${this._BASE_URL}/CreatePlanoAlimentarRecord`;

    return this.httpClient.post<RetId>(URL, record, { headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetId) => this.showErrorMessage(response)));
  }
  // #endregion CREATE

  // #region UPDATE
  public updatePlanoAlimentarRecordById(record: PlanoAlimentar): Observable<RetError> {
    const URL: string = `${this._BASE_URL}/UpdatePlanoAlimentarRecordById`;

    return this.httpClient.post<RetError>(URL, record, { headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetError) => this.showErrorMessage(response)));
  }
  // #endregion UPDATE

  // #region DELETE
  public deletePlanoAlimentarRecord(planoAlimentarId: string): Observable<RetError> {
    const HTTP_PARAMS: HttpParams = new HttpParams()
      .set('planoAlimentarId', planoAlimentarId);

    const URL: string = `${this._BASE_URL}/DeletePlanoAlimentarRecord`;

    return this.httpClient.get<RetError>(URL, { params: HTTP_PARAMS, headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetError) => this.showErrorMessage(response)));
  }
  // #endregion DELETE

  // #endregion ==========> SERVICE METHODS <==========


  // #region ==========> UTILITIES <==========
  private showErrorMessage(response: RetError): void { if (response.Error) throw Error(response.ErrorMessage); }
  // #endregion ==========> UTILITIES <==========


}
