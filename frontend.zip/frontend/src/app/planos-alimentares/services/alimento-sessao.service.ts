import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, take, tap } from 'rxjs';
import { RetError } from '../../../project/models/ret-error';

@Injectable({
  providedIn: 'root'
})
export class AlimentoSessaoService {

  constructor(
    private httpClient: HttpClient
  ) { }


  // #region ==========> PROPERTIES <==========
  private readonly _BASE_URL: string = `http://localhost:44384/api/AlimentoSessao`;
  private readonly _HTTP_HEADERS: HttpHeaders = new HttpHeaders().set('Content-Type', 'application/json');
  // #endregion ==========> PROPERTIES <==========


  // #region ==========> SERVICE METHODS <==========

  // #region CREATE
  public createAlimentoSessaoRecord(alimentoId: string, sessaoAlimentarId: string, dose: number): Observable<RetError> {
    const HTTP_PARAMS: HttpParams = new HttpParams()
      .set('alimentoId', alimentoId)
      .set('sessaoAlimentarId', sessaoAlimentarId)
      .set('dose', dose);

    const URL: string = `${this._BASE_URL}/CreateAlimentoSessaoRecord`;

    return this.httpClient.get<RetError>(URL, { params: HTTP_PARAMS, headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetError) => this.showErrorMessage(response)));
  }
  // #endregion CREATE

  // #region DELETE
  public deleteAlimentoSessaoRecordById(alimentoSessaoId: string): Observable<RetError> {
    const HTTP_PARAMS: HttpParams = new HttpParams()
      .set('alimentoSessaoId', alimentoSessaoId);

    const URL: string = `${this._BASE_URL}/DeleteAlimentoSessaoRecordById`;

    return this.httpClient.get<RetError>(URL, { params: HTTP_PARAMS, headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetError) => this.showErrorMessage(response)));
  }
  // #endregion DELETE

  // #endregion ==========> SERVICE METHODS <==========


  // #region ==========> UTILITIES <==========
  private showErrorMessage(response: RetError): void { if (response.Error) throw Error(response.ErrorMessage); }
  // #endregion ==========> UTILITIES <==========


}
