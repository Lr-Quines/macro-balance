import { Component, OnInit, TemplateRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { PlanosAlimentaresService } from './services/planos-alimentares.service';
import { AuthStorageService } from '../../project/services/auth-storage.service';
import { RetPlanoAlimentarList } from './models/ret-plano-alimentar-list';
import { MatSnackBar } from '@angular/material/snack-bar';
import { PlanoAlimentar } from './models/plano-alimentar';

@Component({
  selector: 'mb-planos-alimentares',
  templateUrl: './planos-alimentares.component.html',
  styleUrl: './planos-alimentares.component.scss'
})
export class PlanosAlimentaresComponent implements OnInit {

  constructor(
    private _matDialog: MatDialog,
    private _planosAlimentaresService: PlanosAlimentaresService,
    private _authStorageService: AuthStorageService,
    private _matSnackBar: MatSnackBar
  ) { }

  public ngOnInit(): void {
    this.preparationPlanoAlimentarList();
  }


  // #region ==========> PROPERTIES <==========

  // #region PRIVATE
  // #endregion PRIVATE

  // #region PROTECTED
  protected displayedColumns: string[] = ['Nome', 'Descricao', 'Caloria', 'Carboidrato', 'Gordura', 'Proteina', 'Acoes'];

  protected planoAlimentarList: PlanoAlimentar[] = [];

  protected isLoaginPage: boolean = true;
  // #endregion PROTECTED

  // #region PUBLIC
  // #endregion PUBLIC

  // #endregion ==========> PROPERTIES <==========


  // #region ==========> SERVICE METHODS <==========

  // #region GET
  protected preparationPlanoAlimentarList(): void {
    this.isLoaginPage = true;
    this._planosAlimentaresService.preparationPlanoAlimentarList(this._authStorageService.userId).subscribe({
      next: (response: RetPlanoAlimentarList) => {
        this.planoAlimentarList = response.PlanoAlimentarList;
        this.isLoaginPage = false;
      },
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error.message}`, 'X')
    });
  }
  // #endregion GET

  // #region DELETE
  protected deletePlanoAlimentarRecord(planoAlimentarId: string, nome: string): void {
    this._planosAlimentaresService.deletePlanoAlimentarRecord(planoAlimentarId).subscribe({
      next: () => {
        this._matDialog.closeAll();
        this._matSnackBar.open(`Plano alimentar "${nome}" excluído com sucesso`, 'X');
        this.preparationPlanoAlimentarList();
      },
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error.message}`, 'X')
    });
  }
  // #endregion DELETE

  // #endregion ==========> SERVICE METHODS <==========


  // #region ==========> UTILITIES <==========
  protected openDialog(dialog: TemplateRef<any>): void {
    this._matDialog.open(dialog, {
      width: '350px'
    });
  }
  // #endregion ==========> UTILITIES <==========


}
