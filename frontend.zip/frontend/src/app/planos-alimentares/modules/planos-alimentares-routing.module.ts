import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PlanosAlimentaresComponent } from '../planos-alimentares.component';
import { AlterarPlanoAlimentarComponent } from '../alterar-plano-alimentar/alterar-plano-alimentar.component';

const routes: Routes = [
  { path: '', component: PlanosAlimentaresComponent, data: { title: 'Planos alimentares' } },
  { path: ':plano-alimentar-id', component: AlterarPlanoAlimentarComponent, data: { title: 'Plano alimentar' } },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PlanosAlimentaresRoutingModule { }
