import { Component, OnInit, TemplateRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PlanoAlimentar } from '../models/plano-alimentar';
import { PlanosAlimentaresService } from '../services/planos-alimentares.service';
import { RetPlanoAlimentar } from '../models/ret-plano-alimentar';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { SessaoAlimentarService } from '../services/sessao-alimentar.service';
import { AlimentoSessaoService } from '../services/alimento-sessao.service';

@Component({
  selector: 'mb-alterar-plano-alimentar',
  templateUrl: './alterar-plano-alimentar.component.html',
  styleUrl: './alterar-plano-alimentar.component.scss'
})
export class AlterarPlanoAlimentarComponent implements OnInit {

  constructor(
    private _activatedRoute: ActivatedRoute,
    private _planosAlimentaresService: PlanosAlimentaresService,
    private _sessaoAlimentarService: SessaoAlimentarService,
    private _alimentoSessaoService: AlimentoSessaoService,
    private _matSnackBar: MatSnackBar,
    private _matDialog: MatDialog
  ) {
    this.PLANO_ALIMENTAR_ID = this._activatedRoute.snapshot.params['plano-alimentar-id'];
  }

  public ngOnInit(): void {
    this.getPlanoSessaoAlimentarById();
  }


  // #region ==========> PROPERTIES <==========

  // #region PROTECTED
  protected displayedColumns: string[] = ['Nome', 'Dose', 'Caloria', 'Carboidrato', 'Gordura', 'Proteina', 'Acoes'];
  protected planoAlimentar: PlanoAlimentar = new PlanoAlimentar();

  protected isLoaginPage: boolean = true;

  protected readonly PLANO_ALIMENTAR_ID: string = '';
  // #endregion PROTECTED

  // #region PUBLIC
  // #endregion PUBLIC

  // #endregion ==========> PROPERTIES <==========


  // #region ==========> SERVICE METHODS <==========

  // #region GET
  protected getPlanoSessaoAlimentarById(): void {
    this.isLoaginPage = true;
    this._planosAlimentaresService.getPlanoSessaoAlimentarById(this.PLANO_ALIMENTAR_ID).subscribe({
      next: (response: RetPlanoAlimentar) => {
        this.planoAlimentar = response.PlanoAlimentar;
        this.isLoaginPage = false;
      },
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error.message}`, 'X')
    });
  }
  // #endregion GET

  // #region DELETE
  protected deletePlanoAlimentarRecord(sessaoAlimentarId: string, nome: string): void {
    this._sessaoAlimentarService.deleteSessaoAlimentarRecordById(sessaoAlimentarId).subscribe({
      next: () => {
        this._matDialog.closeAll();
        this._matSnackBar.open(`Sessão alimentar "${nome}" excluída com sucesso`, 'X');
        this.getPlanoSessaoAlimentarById();
      },
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error.message}`, 'X')
    });
  }

  protected deleteAlimentoSessaoRecordById(alimentoSessaoId: string, nomeAlimento: string, nomeSessao: string): void {
    this._alimentoSessaoService.deleteAlimentoSessaoRecordById(alimentoSessaoId).subscribe({
      next: () => {
        this._matDialog.closeAll();
        this._matSnackBar.open(`Alimento "${nomeAlimento}" excluído da sessão "${nomeSessao}" com sucesso`, 'X');
        this.getPlanoSessaoAlimentarById();
      },
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error.message}`, 'X')
    });
  }
  // #endregion DELETE

  // #endregion ==========> SERVICE METHODS <==========


  // #region ==========> UTILITIES <==========
  protected openDialog(dialog: TemplateRef<any>): void {
    this._matDialog.open(dialog, {
      width: '350px'
    });
  }
  // #endregion ==========> UTILITIES <==========


}
