import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SessaoAlimentarService } from '../../services/sessao-alimentar.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { FormUtilsService } from '../../../../project/services/form-utils.service';
import { RetId } from '../../../../project/models/ret-id';

@Component({
  selector: 'mb-dialog-adicionar-sessao-alimentar',
  templateUrl: './dialog-adicionar-sessao-alimentar.component.html',
  styleUrl: './dialog-adicionar-sessao-alimentar.component.scss'
})
export class DialogAdicionarSessaoAlimentarComponent {

  constructor(
    private _formBuilder: FormBuilder,
    private _sessaoAlimentarService: SessaoAlimentarService,
    private _matSnackBar: MatSnackBar,
    private _matDialog: MatDialog
  ) {
    this.createBaseForm();
  }

  public ngOnInit(): void {
    if (this.sessaoAlimentarId) if (this.sessaoAlimentarId.length > 0) this.isEditingMode = true;
    if (this.isEditingMode) this.getSessaoAlimentarRecordById();
  }


  // #region ==========> PROPERTIES <==========

  // #region PRIVATE
  @Output('updateList') private readonly _EMIT_UPDATE_LIST: EventEmitter<void> = new EventEmitter<void>();
  // #endregion PRIVATE

  // #region PROTECTED
  protected isEditingMode: boolean = false;
  // #endregion PROTECTED

  // #region PUBLIC
  @Input({ required: true }) public sessaoAlimentarId: string = '';
  @Input({ required: true }) public planoAlimentarId: string = '';
  // #endregion PUBLIC

  // #endregion ==========> PROPERTIES <==========


  // #region ==========> FORM BUILDER <==========
  protected form!: FormGroup;

  // #region GETTERS
  private get nome(): string { return this.form.get('nome')?.value.trim(); }
  // #endregion GETTERS

  // #region SETTERS
  private set nome(value: string) { this.form.get('nome')?.setValue(value); }
  // #endregion SETTERS

  // #region FORM VALIDATORS
  private createBaseForm(): void {
    this.form = this._formBuilder.group({
      nome: ['', Validators.required],
    });
  }
  // #endregion FORM VALIDATORS

  // #endregion ==========> FORM BUILDER <==========


  // #region ==========> SERVICE METHODS <==========

  // #region GET
  private getSessaoAlimentarRecordById(): void {
    this._sessaoAlimentarService.getSessaoAlimentarRecordById(this.sessaoAlimentarId).subscribe({
      next: (response: RetId) => this.nome = response.Id,
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error.message}`, 'X')
    });
  }
  // #endregion GET

  // #region CREATE
  protected createSessaoAlimentarRecord(): void {
    if (this.form.invalid) { FormUtilsService.validateFields(this.form); return; }

    this._sessaoAlimentarService.createSessaoAlimentarRecord(this.nome, this.planoAlimentarId).subscribe({
      next: () => {
        this._matSnackBar.open(`Sessão alimentar "${this.nome}" cadastrada com sucesso!`, 'X', { duration: 3500 });
        this._matDialog.closeAll();
        this._EMIT_UPDATE_LIST.emit();
      },
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error}`, 'X')
    });
  }
  // #endregion CREATE

  // #region UPDATE
  protected updateSessaoAlimentarRecordById(): void {
    if (this.form.invalid) { FormUtilsService.validateFields(this.form); return; }

    this._sessaoAlimentarService.updateSessaoAlimentarRecordById(this.nome, this.sessaoAlimentarId).subscribe({
      next: () => {
        this._matSnackBar.open(`Sessão alimentar "${this.nome}" atualizada com sucesso!`, 'X', { duration: 3500 });
        this._matDialog.closeAll();
        this._EMIT_UPDATE_LIST.emit();
      },
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error}`, 'X')
    });
  }
  // #endregion UPDATE

  // #endregion ==========> SERVICE METHODS <==========


}
