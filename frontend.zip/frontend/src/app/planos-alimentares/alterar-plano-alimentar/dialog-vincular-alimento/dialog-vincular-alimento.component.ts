import { Component, EventEmitter, Input, OnInit, Output, TemplateRef } from '@angular/core';
import { AlimentoService } from '../../../meus-alimentos/services/alimento.service';
import { AuthStorageService } from '../../../../project/services/auth-storage.service';
import { RetPreparationAlimentoList } from '../../../meus-alimentos/models/ret-preparation-alimento-list';
import { Alimento } from '../../../meus-alimentos/models/alimento';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AlimentoSessaoService } from '../../services/alimento-sessao.service';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'mb-dialog-vincular-alimento',
  templateUrl: './dialog-vincular-alimento.component.html',
  styleUrl: './dialog-vincular-alimento.component.scss'
})
export class DialogVincularAlimentoComponent implements OnInit {

  constructor(
    private _alimentoService: AlimentoService,
    private _alimentoSessaoService: AlimentoSessaoService,
    private _authStorageService: AuthStorageService,
    private _matSnackBar: MatSnackBar,
    private _formBuilder: FormBuilder,
    private _matDialog: MatDialog
  ) {
    this.createBaseForm();
  }

  public ngOnInit(): void {
    this.getAlimentoCombobox();
  }


  // #region ==========> PROPERTIES <==========

  // #region PRIVATE
  @Output('updateList') private readonly _EMIT_UPDATE_LIST: EventEmitter<void> = new EventEmitter<void>();
  // #endregion PRIVATE

  // #region PROTECTED
  protected alimentoCombobox: Alimento[] = [];

  protected calorias: number = 0;
  protected carboidratos: number = 0;
  protected proteinas: number = 0;
  protected gorduras: number = 0;
  // #endregion PROTECTED

  // #region PUBLIC
  @Input({ required: true }) public sessaoAlimentarId: string = '';
  // #endregion PUBLIC

  // #endregion ==========> PROPERTIES <==========


  // #region ==========> FORM BUILDER <==========
  protected form!: FormGroup;

  // #region GETTERS
  protected get alimento(): string { return this.form.get('alimento')?.value; }
  private get dose(): number { return this.form.get('dose')?.value; }
  // #endregion GETTERS

  // #region SETTERS
  private set alimento(value: string) { this.form.get('alimento')?.setValue(value); }
  private set dose(value: number) { this.form.get('dose')?.setValue(value); }
  // #endregion SETTERS

  // #region FORM VALIDATORS
  private createBaseForm(): void {
    this.form = this._formBuilder.group({
      alimento: ['', Validators.required],
      dose: ['', Validators.required]
    });
  }
  // #endregion FORM VALIDATORS

  // #endregion ==========> FORM BUILDER <==========


  // #region ==========> SERVICE METHODS <==========

  // #region GET
  protected getAlimentoCombobox(): void {
    this._alimentoService.preparationAlimentoList(this._authStorageService.userId).subscribe({
      next: (response: RetPreparationAlimentoList) => this.alimentoCombobox = response.AlimentoList,
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error.message}`, 'X')
    });
  }
  // #endregion GET

  // #region CREATE
  protected createAlimentoSessaoRecord(): void {
    this._alimentoSessaoService.createAlimentoSessaoRecord(this.alimento, this.sessaoAlimentarId, this.dose).subscribe({
      next: () => {
        this._matSnackBar.open(`Alimento "${this.alimentoNome}" adicionado com sucesso!`, 'X', { duration: 3500 });
        this._matDialog.closeAll();
        this._EMIT_UPDATE_LIST.emit();
      },
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error}`, 'X')
    })
  }
  // #endregion CREATE

  // #endregion ==========> SERVICE METHODS <==========


  // #region ==========> UTILITIES <==========
  protected setDose(): void {
    const ALIMENTO: Alimento | undefined = this.alimentoCombobox.find(e => e.Id == this.alimento);

    if (ALIMENTO) this.dose = ALIMENTO.Dose;
  }

  protected qtdCaloria(): void {
    const ALIMENTO: Alimento | undefined = this.alimentoCombobox.find(e => e.Id == this.alimento);

    if (ALIMENTO) this.calorias = ALIMENTO.Caloria;
    else this.calorias = 0;
  }

  protected qtdCarboidrato(): void {
    const ALIMENTO: Alimento | undefined = this.alimentoCombobox.find(e => e.Id == this.alimento);

    if (ALIMENTO) this.carboidratos = ALIMENTO.Carboidrato;
    else this.carboidratos = 0;
  }

  protected qtdProteina(): void {
    const ALIMENTO: Alimento | undefined = this.alimentoCombobox.find(e => e.Id == this.alimento);

    if (ALIMENTO) this.proteinas = ALIMENTO.Proteina;
    else this.proteinas = 0;
  }

  protected qtdGordura(): void {
    const ALIMENTO: Alimento | undefined = this.alimentoCombobox.find(e => e.Id == this.alimento);

    if (ALIMENTO) this.gorduras = ALIMENTO.Gordura;
    else this.gorduras = 0;
  }

  protected get alimentoNome(): string {
    const ALIMENTO: Alimento | undefined = this.alimentoCombobox.find(e => e.Id == this.alimento);

    if (ALIMENTO) return ALIMENTO.Nome;
    else return '';
  }

  protected get unidadeMedida(): string {
    const ALIMENTO: Alimento | undefined = this.alimentoCombobox.find(e => e.Id == this.alimento);

    if (ALIMENTO) return ALIMENTO.UnidadeMedida;
    else return '';
  }

  protected setMacroNutrientes(): void {
    const ALIMENTO: Alimento | undefined = this.alimentoCombobox.find(e => e.Id == this.alimento);

    this.calorias = (ALIMENTO!.Caloria / ALIMENTO!.Dose) * this.dose;
    this.carboidratos = (ALIMENTO!.Carboidrato / ALIMENTO!.Dose) * this.dose;
    this.proteinas = (ALIMENTO!.Proteina / ALIMENTO!.Dose) * this.dose;
    this.gorduras = (ALIMENTO!.Gordura / ALIMENTO!.Dose) * this.dose;
  }

  protected openDialogAdicionarAlimento(dialog: TemplateRef<any>): void {
    this._matDialog.open(dialog, {
      width: '1000px'
    });
  }
  // #endregion ==========> UTILITIES <==========


}
