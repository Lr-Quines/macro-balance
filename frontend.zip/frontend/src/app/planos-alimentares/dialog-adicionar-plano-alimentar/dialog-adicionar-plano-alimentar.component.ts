import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PlanosAlimentaresService } from '../services/planos-alimentares.service';
import { AuthStorageService } from '../../../project/services/auth-storage.service';
import { RetValidatePlanoAlimentar } from '../models/ret-validate-plano-alimentar';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FormUtilsService } from '../../../project/services/form-utils.service';
import { PlanoAlimentar } from '../models/plano-alimentar';
import { RetId } from '../../../project/models/ret-id';
import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { RetPlanoAlimentar } from '../models/ret-plano-alimentar';

@Component({
  selector: 'mb-dialog-adicionar-plano-alimentar',
  templateUrl: './dialog-adicionar-plano-alimentar.component.html',
  styleUrl: './dialog-adicionar-plano-alimentar.component.scss'
})
export class DialogAdicionarPlanoAlimentarComponent implements OnInit {

  constructor(
    private _formBuilder: FormBuilder,
    private _planosAlimentaresService: PlanosAlimentaresService,
    private _authStorageService: AuthStorageService,
    private _matDialogRef: MatDialogRef<DialogAdicionarPlanoAlimentarComponent>,
    private _matSnackBar: MatSnackBar,
    private _router: Router
  ) {
    this.createBaseForm();
  }

  public ngOnInit(): void {
    if (this.planoAlimentarId) if (this.planoAlimentarId.length > 0) this.isEditingMode = true;
    if (this.isEditingMode) this.getPlanoAlimentarRecordById();
  }


  // #region ==========> PROPERTIES <==========

  // #region PRIVATE
  @Output('updateList') private readonly _EMIT_UPDATE_LIST: EventEmitter<void> = new EventEmitter<void>();
  // #endregion PRIVATE

  // #region PROTECTED
  protected isEditingMode: boolean = false;
  // #endregion PROTECTED

  // #region PUBLIC
  @Input({ required: true }) public planoAlimentarId: string = '';
  // #endregion PUBLIC

  // #endregion ==========> PROPERTIES <==========


  // #region ==========> FORM BUILDER <==========
  protected form!: FormGroup;

  // #region GETTERS
  private get nome(): string { return this.form.get('nome')?.value.trim(); }
  private get descricao(): string { return this.form.get('descricao')?.value.trim(); }
  // #endregion GETTERS

  // #region SETTERS
  private set nome(value: string) { this.form.get('nome')?.setValue(value); }
  private set descricao(value: string) { this.form.get('descricao')?.setValue(value); }
  // #endregion SETTERS

  // #region FORM VALIDATORS
  private createBaseForm(): void {
    this.form = this._formBuilder.group({
      nome: ['', Validators.required],
      descricao: '',
    });
  }
  // #endregion FORM VALIDATORS

  // #endregion ==========> FORM BUILDER <==========


  // #region ==========> SERVICE METHODS <==========

  // #region GET
  protected validatePlanoAlimentar(): void {
    this._planosAlimentaresService.validatePlanoAlimentar(this.nome, this._authStorageService.userId, this.planoAlimentarId).subscribe({
      next: (response: RetValidatePlanoAlimentar) => this.validate(response.NomeExists),
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error.message}`, 'X')
    });
  }

  private getPlanoAlimentarRecordById(): void {
    this._planosAlimentaresService.getPlanoAlimentarRecordById(this.planoAlimentarId).subscribe({
      next: (response: RetPlanoAlimentar) => {
        this.nome = response.PlanoAlimentar.Nome;
        this.descricao = response.PlanoAlimentar.Descricao;
      },
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error.message}`, 'X')
    });
  }
  // #endregion GET

  // #region CREATE
  private createPlanoAlimentarRecord(): void {
    const RECORD: PlanoAlimentar = this.assignValue();

    this._planosAlimentaresService.createPlanoAlimentarRecord(RECORD).subscribe({
      next: (response: RetId) => {
        this._matSnackBar.open(`Plano alimentar "${this.nome}" cadastrado com sucesso!`, 'X', { duration: 3500 });
        this._matDialogRef.close();
        this._router.navigate(['/planos-alimentares', response.Id]);
      },
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error}`, 'X')
    });
  }
  // #endregion CREATE

  // #region UPDATE
  private updatePlanoAlimentarRecordById(): void {
    const RECORD: PlanoAlimentar = this.assignValue();

    this._planosAlimentaresService.updatePlanoAlimentarRecordById(RECORD).subscribe({
      next: () => {
        this._matSnackBar.open(`Plano alimentar "${this.nome}" atualizado com sucesso!`, 'X', { duration: 3500 });
        this._matDialogRef.close();
        this._EMIT_UPDATE_LIST.emit();
      },
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error}`, 'X')
    });
  }
  // #endregion UPDATE

  // #endregion ==========> SERVICE METHODS <==========


  // #region ==========> UTILITIES <==========
  private assignValue(): PlanoAlimentar {
    return {
      Id: this.planoAlimentarId,
      Nome: this.nome,
      Descricao: this.descricao,
      UsuarioCriador: this._authStorageService.userId
    };
  }

  private validate(nomeExists: boolean): void {
    if (this.form.invalid) FormUtilsService.validateFields(this.form);

    if (nomeExists) this._matSnackBar.open(`Você já tem um plano alimentar com o nome "${this.nome}"`, 'X');
    else if (this.form.valid) this.isEditingMode ? this.updatePlanoAlimentarRecordById() : this.createPlanoAlimentarRecord();
  }
  // #endregion ==========> UTILITIES <==========


}
