import { AlimentoSessao } from "./alimento-sessao";

export class SessaoAlimentar {
  public Id: string = '';
  public Nome: string = '';
  public Caloria: number = 0;
  public Carboidrato: number = 0;
  public Proteina: number = 0;
  public Gordura: number = 0;
  public AlimentoSessaoList: AlimentoSessao[] = [];
}
