export class AlimentoSessao {
  public Id: string = '';
  public Alimento: string = '';
  public Marca: string = '';
  public Caloria: number = 0;
  public Carboidrato: number = 0;
  public Proteina: number = 0;
  public Gordura: number = 0;
  public Dose: number = 0;
  public UnidadeMedida: string = '';
  public UnidadeMedidaSimbolo: string = '';
}
