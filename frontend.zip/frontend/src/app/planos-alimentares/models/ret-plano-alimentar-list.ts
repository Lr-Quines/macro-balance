import { RetError } from "../../../project/models/ret-error";
import { PlanoAlimentar } from "./plano-alimentar";

export class RetPlanoAlimentarList extends RetError {
  public PlanoAlimentarList: PlanoAlimentar[] = [];
}
