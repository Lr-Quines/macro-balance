import { RetError } from "../../../project/models/ret-error";

export class RetValidatePlanoAlimentar extends RetError {
  public NomeExists: boolean = true;
}
