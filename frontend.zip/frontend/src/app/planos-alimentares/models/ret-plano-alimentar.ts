import { RetError } from "../../../project/models/ret-error";
import { PlanoAlimentar } from "./plano-alimentar";

export class RetPlanoAlimentar extends RetError {
  public PlanoAlimentar: PlanoAlimentar = new PlanoAlimentar();
}
