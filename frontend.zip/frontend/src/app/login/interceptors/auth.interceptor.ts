import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { AuthService } from "../services/auth.service";
import { Observable } from "rxjs";

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  constructor(
    private authService: AuthService
  ) { }

  public intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const TOKEN: string | null = this.authService.getToken();

    if (TOKEN) {
      request = request.clone({
        setHeaders: {
          Authorization: `Bearer ${TOKEN}`
        }
      });
    }

    return next.handle(request);
  }
}
