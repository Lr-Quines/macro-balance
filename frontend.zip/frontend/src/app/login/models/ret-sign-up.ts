import { RetError } from "../../../project/models/ret-error";

export class RetSignUp extends RetError {
  public UserId: string = '';
  public Token: string = '';
}
