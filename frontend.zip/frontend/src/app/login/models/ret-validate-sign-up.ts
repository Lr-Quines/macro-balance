import { RetError } from "../../../project/models/ret-error";

export class RetValidateSignUp extends RetError {
  public UsernameExists: boolean = true;
  public EmailExists: boolean = true;
}
