import { RetError } from "../../../project/models/ret-error";

export class RetSignIn extends RetError {
  public IsSuccess: boolean = false;
  public UserId: string = '';
  public Username: string = '';
  public Token: string = '';
}
