export class User {
  Username: string = '';
  Email: string = '';
  Password: string = '';
}
