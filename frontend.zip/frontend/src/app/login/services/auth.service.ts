import { Inject, Injectable, PLATFORM_ID, afterNextRender } from '@angular/core';
import { User } from '../models/user';
import { Observable, take, tap } from 'rxjs';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { RetSignIn } from '../models/ret-sign-in';
import { RetError } from '../../../project/models/ret-error';
import { RetSignUp } from '../models/ret-sign-up';
import { RetValidateSignUp } from '../models/ret-validate-sign-up';
import { isPlatformBrowser } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(
    private httpClient: HttpClient,
    @Inject(PLATFORM_ID) private _platformId: Object
  ) { }


  // #region ==========> PROPERTIES <==========
  private readonly _BASE_URL: string = `http://localhost:44384/api/Auth`;
  private readonly _HTTP_HEADERS: HttpHeaders = new HttpHeaders().set('Content-Type', 'application/json');
  // #endregion ==========> PROPERTIES <==========


  // #region ==========> SERVICE METHODS <==========

  // #region GET
  public signIn(password: string, usernameEmail: string): Observable<RetSignIn> {
    const HTTP_PARAMS: HttpParams = new HttpParams()
      .set('usernameEmail', usernameEmail);

    const URL: string = `${this._BASE_URL}/SignIn`;

    return this.httpClient.post<RetSignIn>(URL, JSON.stringify(password), { params: HTTP_PARAMS, headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetSignIn) => this.showErrorMessage(response)));
  }

  public signUp(user: User): Observable<RetSignUp> {
    const URL: string = `${this._BASE_URL}/SignUp`;

    return this.httpClient.post<RetSignUp>(URL, user, { headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetSignUp) => this.showErrorMessage(response)));
  }

  public validateSignUp(username: string, email: string): Observable<RetValidateSignUp> {
    const HTTP_PARAMS: HttpParams = new HttpParams()
      .set('username', username)
      .set('email', email);

    const URL: string = `${this._BASE_URL}/ValidateSignUp`;

    return this.httpClient.get<RetValidateSignUp>(URL, { params: HTTP_PARAMS, headers: this._HTTP_HEADERS })
      .pipe(take(1), tap((response: RetValidateSignUp) => this.showErrorMessage(response)));
  }
  // #endregion GET

  // #endregion ==========> SERVICE METHODS <==========


  // #region ==========> UTILITIES <==========
  private showErrorMessage(response: RetError): void { if (response.Error) throw Error(response.ErrorMessage); }

  public getToken(): string | null {
    if (isPlatformBrowser(this._platformId)) return localStorage.getItem('token');
    else return null;
  }
  // #endregion ==========> UTILITIES <==========


}
