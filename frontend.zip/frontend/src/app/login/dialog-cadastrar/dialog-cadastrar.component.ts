import { Component } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { User } from '../models/user';
import { RetValidateSignUp } from '../models/ret-validate-sign-up';
import { MatSnackBar } from '@angular/material/snack-bar';
import { RetSignUp } from '../models/ret-sign-up';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormUtilsService } from '../../../project/services/form-utils.service';

@Component({
  selector: 'mb-dialog-cadastrar',
  templateUrl: './dialog-cadastrar.component.html',
  styleUrl: './dialog-cadastrar.component.scss'
})
export class DialogCadastrarComponent {

  constructor(
    private _authService: AuthService,
    private _matSnackBar: MatSnackBar,
    private _router: Router,
    private _formBuilder: FormBuilder
  ) {
    this.createBaseForm();
  }


  // #region ==========> PROPERTIES <==========

  // #region PROTECTED
  protected user: User = new User();
  // #endregion PROTECTED

  // #endregion ==========> PROPERTIES <==========


  // #region ==========> FORM BUILDER <==========
  protected form!: FormGroup;

  // #region FORM DATA
  private get email(): string { return this.form.get('email')?.value.trim(); }
  private get username(): string { return this.form.get('username')?.value.trim(); }
  private get password(): string { return this.form.get('password')?.value.trim(); }
  // #endregion FORM DATA

  // #region FORM VALIDATORS
  private createBaseForm(): void {
    this.form = this._formBuilder.group({
      email: ['', Validators.required],
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }
  // #endregion FORM VALIDATORS

  // #endregion ==========> FORM BUILDER <==========


  // #region ==========> SERVICE METHODS <==========

  // #region GET
  protected validateSignUp(): void {
    if (!this.form.valid) { FormUtilsService.validateFields(this.form); return; }

    this._authService.validateSignUp(this.username, this.email).subscribe({
      next: (response: RetValidateSignUp) => this.validate(response.UsernameExists, response.EmailExists),
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error}`, 'X')
    });
  }
  // #endregion GET

  // #region CREATE
  private signUp(): void {
    const USER: User = this.assignValues();

    this._authService.signUp(USER).subscribe({
      next: (response: RetSignUp) => {
        localStorage.setItem('username', this.username);
        localStorage.setItem('userid', response.UserId);
        localStorage.setItem('token', response.Token);

        this._router.navigate(['/planos-alimentares']);
      },
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error}`, 'X')
    });
  }
  // #endregion CREATE

  // #endregion ==========> SERVICE METHODS <==========


  // #region ==========> UTILITIES <==========
  private assignValues(): User {
    return {
      Username: this.username,
      Email: this.email,
      Password: this.password
    };
  }

  private validate(usernameExists: boolean, emailExists: boolean): void {
    if (usernameExists && emailExists) this._matSnackBar.open(`Usuário '${this.username}' e email '${this.email}' já cadastrados`, 'X');
    else if (usernameExists) this._matSnackBar.open(`Usuário '${this.username}' já cadastrado`, 'X');
    else if (emailExists) this._matSnackBar.open(`Email '${this.email}' já cadastrado`, 'X');
    else this.signUp();
  }
  // #endregion ==========> UTILITIES <==========


}
