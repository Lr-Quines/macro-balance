import { Component, TemplateRef } from '@angular/core';
import { AuthService } from './services/auth.service';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { RetSignIn } from './models/ret-sign-in';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormUtilsService } from '../../project/services/form-utils.service';

@Component({
  selector: 'mb-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {

  constructor(
    private _authService: AuthService,
    private _matDialog: MatDialog,
    private _matSnackBar: MatSnackBar,
    private _router: Router,
    private _formBuilder: FormBuilder
  ) {
    this.createBaseForm();
  }


  // #region ==========> PROPERTIES <==========

  // #region PROTECTED
  protected loadingLogin: boolean = false;
  // #endregion PROTECTED

  // #endregion ==========> PROPERTIES <==========


  // #region ==========> FORM BUILDER <==========
  protected form!: FormGroup;

  // #region FORM DATA
  private get usernameEmail(): string { return this.form.get('usernameEmail')?.value; }
  private get password(): string { return this.form.get('password')?.value; }
  // #endregion FORM DATA

  // #region FORM VALIDATORS
  private createBaseForm(): void {
    this.form = this._formBuilder.group({
      usernameEmail: ['', Validators.required],
      password: ['', Validators.required]
    });
  }
  // #endregion FORM VALIDATORS

  // #endregion ==========> FORM BUILDER <==========


  // #region ==========> SERVICE METHODS <==========
  protected signIn(): void {
    if (!this.form.valid) { FormUtilsService.validateFields(this.form); return; }

    this.loadingLogin = true;

    this._authService.signIn(this.password, this.usernameEmail).subscribe({
      next: (response: RetSignIn) => {
        if (response.IsSuccess) {
          localStorage.setItem('username', response.Username);
          localStorage.setItem('userid', response.UserId);
          localStorage.setItem('token', response.Token);

          this._router.navigate(['/planos-alimentares']);
        }
        else this._matSnackBar.open('Usuário, email e/ou senha incorretos...', 'X');

        this.loadingLogin = false;
      },
      error: (error: any) => this._matSnackBar.open(`Ocorreu um erro: ${error}`, 'X')
    });
  }
  // #endregion ==========> SERVICE METHODS <==========


  // #region ==========> UTILITIES <==========
  protected openDialogSignOn(dialog: TemplateRef<any>): void {
    this._matDialog.open(dialog, {
      width: '400px'
    });
  }
  // #endregion ==========> UTILITIES <==========


}
