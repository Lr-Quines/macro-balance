import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './login/guards/auth.guard';
import { SideMenuComponent } from '../project/components/side-menu/side-menu.component';

const routes: Routes = [
  {
    path: 'login',
    loadChildren: () => import('./login/modules/login.module').then((m) => m.LoginModule)
  },
  {
    path: '',
    component: SideMenuComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: 'meus-alimentos',
        loadChildren: () => import('./meus-alimentos/modules/meus-alimentos.module').then((m) => m.MeusAlimentosModule),
        canActivate: [AuthGuard]
      },
      {
        path: 'planos-alimentares',
        loadChildren: () => import('./planos-alimentares/modules/planos-alimentares.module').then((m) => m.PlanosAlimentaresModule),
        canActivate: [AuthGuard]
      },
      {
        path: '',
        redirectTo: 'planos-alimentares',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: '**',
    redirectTo: '/login',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
