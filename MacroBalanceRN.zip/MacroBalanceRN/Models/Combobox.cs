﻿using System.Runtime.Serialization;

namespace MacroBalanceRN.Models
{
    [DataContract]
    public class Combobox
    {
        [DataMember]
        public string Id { get; set; }

        [DataMember]
        public string Label { get; set; }
    }
}
