﻿using System.Runtime.Serialization;

namespace MacroBalanceRN.Models
{
    [DataContract]
    public class AlimentoSessao
    {
        [DataMember]
        public string Id { get; set; }

        [DataMember]
        public string Alimento { get; set; }

        [DataMember]
        public string Marca { get; set; }

        [DataMember]
        public decimal Caloria { get; set; }

        [DataMember]
        public decimal Carboidrato { get; set; }

        [DataMember]
        public decimal Proteina { get; set; }

        [DataMember]
        public decimal Gordura { get; set; }

        [DataMember]
        public decimal Dose { get; set; }

        [DataMember]
        public string UnidadeMedida { get; set; }

        [DataMember]
        public string UnidadeMedidaSimbolo { get; set; }
    }
}
