﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace MacroBalanceRN.Models
{
    [DataContract]
    public class SessaoAlimentar
    {
        [DataMember]
        public string Id { get; set; }

        [DataMember]
        public string Nome { get; set; }

        [DataMember]
        public decimal Caloria { get; set; }

        [DataMember]
        public decimal Carboidrato { get; set; }

        [DataMember]
        public decimal Proteina { get; set; }

        [DataMember]
        public decimal Gordura { get; set; }

        [DataMember]
        public List<AlimentoSessao> AlimentoSessaoList { get; set; }
    }
}
