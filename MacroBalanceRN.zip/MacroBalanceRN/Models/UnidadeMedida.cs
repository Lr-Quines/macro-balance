﻿using System.Runtime.Serialization;

namespace MacroBalanceRN.Models
{
    [DataContract]
    public class UnidadeMedida
    {
        [DataMember]
        public string Id { get; set; }

        [DataMember]
        public string Nome { get; set; }

        [DataMember]
        public string Simbolo { get; set; }

        [DataMember]
        public string UsuarioCriador { get; set; }
    }
}
