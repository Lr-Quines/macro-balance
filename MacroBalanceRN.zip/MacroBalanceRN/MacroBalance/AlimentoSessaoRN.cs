﻿using MacroBalanceRN.Models;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MacroBalanceRN.MacroBalance
{
    public class AlimentoSessaoRN
    {

        #region Connection

        private readonly string _Connection = "server=localhost; database=macrobalance; username=root; password=;";

        #endregion Connection

        #region Public Methods

        #region Get

        public List<AlimentoSessao> GetAlimentoSessaoListBySessaoAlimentar(string sessaoAlimentarId)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                            SELECT    MB_AlimentoSessao.Id,
                                      MB_AlimentoSessao.Dose,
                                      MB_Alimento.Nome,
                                      MB_Alimento.Marca,
                                      MB_UnidadeMedida.Nome AS 'UnidadeMedida',
                                      MB_UnidadeMedida.Simbolo,
                                      COALESCE(ROUND((MB_Alimento.Caloria/MB_Alimento.Dose) * MB_AlimentoSessao.Dose, 1), 0) AS 'Caloria',
                                      COALESCE(ROUND((MB_Alimento.Carboidrato/MB_Alimento.Dose) * MB_AlimentoSessao.Dose, 1), 0) AS 'Carboidrato',
                                      COALESCE(ROUND((MB_Alimento.Proteina/MB_Alimento.Dose) * MB_AlimentoSessao.Dose, 1), 0) AS 'Proteina',
                                      COALESCE(ROUND((MB_Alimento.Gordura/MB_Alimento.Dose) * MB_AlimentoSessao.Dose, 1), 0) AS 'Gordura'

                              FROM    MB_AlimentoSessao
                        INNER JOIN    MB_Alimento      ON MB_AlimentoSessao.AlimentoId = MB_Alimento.Id
                        INNER JOIN    MB_UnidadeMedida ON MB_Alimento.UnidadeMedida    = MB_UnidadeMedida.Id

                             WHERE    MB_AlimentoSessao.SessaoAlimentarId = @SessaoAlimentarId;

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@SessaoAlimentarId", sessaoAlimentarId);

                        using (MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader())
                        {
                            List<AlimentoSessao> recordList = new List<AlimentoSessao>();

                            while (mySqlDataReader.Read())
                            {
                                if (mySqlDataReader["Id"].ToString().Length > 0)
                                {
                                    recordList.Add(new AlimentoSessao
                                    {
                                        Id = mySqlDataReader["Id"].ToString(),
                                        Alimento = mySqlDataReader["Nome"].ToString(),
                                        Marca = mySqlDataReader["Marca"].ToString(),
                                        Caloria = decimal.Parse(mySqlDataReader["Caloria"].ToString()),
                                        Carboidrato = decimal.Parse(mySqlDataReader["Carboidrato"].ToString()),
                                        Proteina = decimal.Parse(mySqlDataReader["Proteina"].ToString()),
                                        Gordura = decimal.Parse(mySqlDataReader["Gordura"].ToString()),
                                        Dose = decimal.Parse(mySqlDataReader["Dose"].ToString()),
                                        UnidadeMedida = mySqlDataReader["UnidadeMedida"].ToString(),
                                        UnidadeMedidaSimbolo = mySqlDataReader["Simbolo"].ToString()
                                    });
                                }

                            }

                            return recordList;
                        }
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        #endregion Get

        #region Create

        public void CreateAlimentoSessaoRecord(string alimentoId, string sessaoAlimentarId, decimal dose)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        INSERT INTO MB_AlimentoSessao
                            (Id
                            ,AlimentoId
                            ,Dose
                            ,SessaoAlimentarId)

                        VALUES
                            (@Id
                            ,@AlimentoId
                            ,@Dose
                            ,@SessaoAlimentarId);

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        string alimentoSessaoId = Guid.NewGuid().ToString();

                        mySqlCommand.Parameters.AddWithValue("@Id", alimentoSessaoId);
                        mySqlCommand.Parameters.AddWithValue("@AlimentoId", alimentoId);
                        mySqlCommand.Parameters.AddWithValue("@Dose", dose);
                        mySqlCommand.Parameters.AddWithValue("@SessaoAlimentarId", sessaoAlimentarId);

                        mySqlCommand.ExecuteNonQuery();
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        #endregion Create

        #region Delete

        public void DeleteAlimentoSessaoRecordById(string alimentoSessaoId)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        DELETE FROM    MB_AlimentoSessao

                              WHERE    Id = @AlimentoSessaoId;

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@AlimentoSessaoId", alimentoSessaoId);

                        mySqlCommand.ExecuteNonQuery();
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        #endregion Delete

        #endregion Public Methods

    }
}
