﻿using MacroBalanceRN.Models;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace MacroBalanceRN.MacroBalance
{
    public class AlimentoRN
    {

        #region Connection

        private readonly string _Connection = "server=localhost; database=macrobalance; username=root; password=;";

        #endregion Connection

        #region Public Methods

        #region Get

        public List<Alimento> GetAlimentoList(string userId)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                            SELECT    MB_Alimento.Id,
                                      MB_Alimento.Nome,
                                      MB_Alimento.Marca,
                                      MB_Alimento.Caloria,
                                      MB_Alimento.Carboidrato,
                                      MB_Alimento.Proteina,
                                      MB_Alimento.Gordura,
                                      MB_Alimento.Dose,
                                      MB_UnidadeMedida.Nome AS 'UnidadeMedida',
                                      MB_UnidadeMedida.Simbolo

                              FROM    MB_Alimento
                        INNER JOIN    MB_UnidadeMedida ON MB_Alimento.UnidadeMedida = MB_UnidadeMedida.Id

                             WHERE    MB_Alimento.UsuarioCriador = @UserId

                          ORDER BY    MB_Alimento.Nome ASC, MB_Alimento.Marca;

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@UserId", userId);

                        using (MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader())
                        {
                            List<Alimento> recordList = new List<Alimento>();

                            while (mySqlDataReader.Read())
                            {
                                recordList.Add(new Alimento
                                {
                                    Id = mySqlDataReader["Id"].ToString(),
                                    Nome = mySqlDataReader["Nome"].ToString(),
                                    Marca = mySqlDataReader["Marca"].ToString(),
                                    Caloria = decimal.Parse(mySqlDataReader["Caloria"].ToString()),
                                    Carboidrato = decimal.Parse(mySqlDataReader["Carboidrato"].ToString()),
                                    Proteina = decimal.Parse(mySqlDataReader["Proteina"].ToString()),
                                    Gordura = decimal.Parse(mySqlDataReader["Gordura"].ToString()),
                                    Dose = decimal.Parse(mySqlDataReader["Dose"].ToString()),
                                    UnidadeMedida = mySqlDataReader["UnidadeMedida"].ToString(),
                                    UsuarioCriador = mySqlDataReader["Simbolo"].ToString()
                                });
                            }

                            return recordList;
                        }
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        public Alimento GetAlimentoRecordById(string alimentoId)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        SELECT    Nome,
                                  Marca,
                                  Caloria,
                                  Carboidrato,
                                  Proteina,
                                  Gordura,
                                  Dose,
                                  UnidadeMedida

                          FROM    MB_Alimento

                         WHERE    Id = @AlimentoId;

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@AlimentoId", alimentoId);

                        using (MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader())
                        {
                            mySqlDataReader.Read();

                            return new Alimento
                            {
                                Nome = mySqlDataReader["Nome"].ToString(),
                                Marca = mySqlDataReader["Marca"].ToString(),
                                Caloria = decimal.Parse(mySqlDataReader["Caloria"].ToString()),
                                Carboidrato = decimal.Parse(mySqlDataReader["Carboidrato"].ToString()),
                                Proteina = decimal.Parse(mySqlDataReader["Proteina"].ToString()),
                                Gordura = decimal.Parse(mySqlDataReader["Gordura"].ToString()),
                                Dose = decimal.Parse(mySqlDataReader["Dose"].ToString()),
                                UnidadeMedida = mySqlDataReader["UnidadeMedida"].ToString(),
                            };
                        }
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }


        public List<Combobox> GetUnidadeMedidaCombobox(string userId)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                          SELECT    Id,
                                    CONCAT(Nome, ' (', Simbolo, ')') AS Nome

                            FROM    MB_UnidadeMedida

                           WHERE    UsuarioCriador = @UserId

                        ORDER BY    Nome ASC;

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@UserId", userId);

                        using (MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader())
                        {
                            List<Combobox> recordList = new List<Combobox>();

                            while (mySqlDataReader.Read())
                            {
                                recordList.Add(new Combobox
                                {
                                    Id = mySqlDataReader["Id"].ToString(),
                                    Label = mySqlDataReader["Nome"].ToString()
                                });
                            }

                            return recordList;
                        }
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        #endregion Get

        #region Create

        public void CreateAlimentoRecord(Alimento record)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        INSERT INTO MB_Alimento
                            (Id
                            ,Nome
                            ,Marca
                            ,Caloria
                            ,Carboidrato
                            ,Proteina
                            ,Gordura
                            ,Dose
                            ,UnidadeMedida
                            ,UsuarioCriador)

                        VALUES
                            (@Id
                            ,@Nome
                            ,@Marca
                            ,@Caloria
                            ,@Carboidrato
                            ,@Proteina
                            ,@Gordura
                            ,@Dose
                            ,@UnidadeMedida
                            ,@UsuarioCriador)

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@Id", Guid.NewGuid().ToString());
                        mySqlCommand.Parameters.AddWithValue("@Nome", record.Nome);
                        mySqlCommand.Parameters.AddWithValue("@Marca", record.Marca);
                        mySqlCommand.Parameters.AddWithValue("@Caloria", record.Caloria);
                        mySqlCommand.Parameters.AddWithValue("@Carboidrato", record.Carboidrato);
                        mySqlCommand.Parameters.AddWithValue("@Proteina", record.Proteina);
                        mySqlCommand.Parameters.AddWithValue("@Gordura", record.Gordura);
                        mySqlCommand.Parameters.AddWithValue("@Dose", record.Dose);
                        mySqlCommand.Parameters.AddWithValue("@UnidadeMedida", record.UnidadeMedida);
                        mySqlCommand.Parameters.AddWithValue("@UsuarioCriador", record.UsuarioCriador);

                        mySqlCommand.ExecuteNonQuery();
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        #endregion Create

        #region Update

        public void UpdateAlimentoRecord(Alimento record)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        UPDATE    MB_Alimento

                           SET    Nome          = @Nome,
                                  Marca         = @Marca,
                                  Caloria       = @Caloria,
                                  Carboidrato   = @Carboidrato,
                                  Proteina      = @Proteina,
                                  Gordura       = @Gordura,
                                  Dose          = @Dose,
                                  UnidadeMedida = @UnidadeMedida

                         WHERE    Id = @Id;

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@Id", record.Id);
                        mySqlCommand.Parameters.AddWithValue("@Nome", record.Nome);
                        mySqlCommand.Parameters.AddWithValue("@Marca", record.Marca);
                        mySqlCommand.Parameters.AddWithValue("@Caloria", record.Caloria);
                        mySqlCommand.Parameters.AddWithValue("@Carboidrato", record.Carboidrato);
                        mySqlCommand.Parameters.AddWithValue("@Proteina", record.Proteina);
                        mySqlCommand.Parameters.AddWithValue("@Gordura", record.Gordura);
                        mySqlCommand.Parameters.AddWithValue("@Dose", record.Dose);
                        mySqlCommand.Parameters.AddWithValue("@UnidadeMedida", record.UnidadeMedida);
                        mySqlCommand.Parameters.AddWithValue("@UsuarioCriador", record.UsuarioCriador);

                        mySqlCommand.ExecuteNonQuery();
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        #endregion Update

        #endregion Public Methods

    }
}
