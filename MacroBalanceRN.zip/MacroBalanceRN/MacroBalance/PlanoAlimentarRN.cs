﻿using MacroBalanceRN.Models;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace MacroBalanceRN.MacroBalance
{
    public class PlanoAlimentarRN
    {

        #region Connection

        private readonly string _Connection = "server=localhost; database=macrobalance; username=root; password=;";

        #endregion Connection

        #region Public Methods

        #region Get

        public List<PlanoAlimentar> GetPlanoAlimentarList(string userId)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                            SELECT    Id,
                                      Nome,
                                      Descricao,
                                      (    SELECT    COALESCE(ROUND(SUM((MB_Alimento.Caloria/MB_Alimento.Dose) * MB_AlimentoSessao.Dose), 1), 0)

                                             FROM    MB_Alimento
                                       INNER JOIN    MB_AlimentoSessao  ON MB_Alimento.Id                      = MB_AlimentoSessao.AlimentoId
                                       INNER JOIN    MB_SessaoAlimentar ON MB_AlimentoSessao.SessaoAlimentarId = MB_SessaoAlimentar.Id

                                            WHERE    MB_SessaoAlimentar.PlanoAlimentarId = MB_PlanoAlimentar.Id) AS 'SUM_Caloria',
                                      (    SELECT    COALESCE(ROUND(SUM((MB_Alimento.Carboidrato/MB_Alimento.Dose) * MB_AlimentoSessao.Dose), 1), 0)

                                             FROM    MB_Alimento
                                       INNER JOIN    MB_AlimentoSessao  ON MB_Alimento.Id                      = MB_AlimentoSessao.AlimentoId
                                       INNER JOIN    MB_SessaoAlimentar ON MB_AlimentoSessao.SessaoAlimentarId = MB_SessaoAlimentar.Id

                                            WHERE    MB_SessaoAlimentar.PlanoAlimentarId = MB_PlanoAlimentar.Id) AS 'SUM_Carboidrato',
                                      (    SELECT    COALESCE(ROUND(SUM((MB_Alimento.Proteina/MB_Alimento.Dose) * MB_AlimentoSessao.Dose), 1), 0)

                                             FROM    MB_Alimento
                                       INNER JOIN    MB_AlimentoSessao  ON MB_Alimento.Id                      = MB_AlimentoSessao.AlimentoId
                                       INNER JOIN    MB_SessaoAlimentar ON MB_AlimentoSessao.SessaoAlimentarId = MB_SessaoAlimentar.Id

                                            WHERE    MB_SessaoAlimentar.PlanoAlimentarId = MB_PlanoAlimentar.Id) AS 'SUM_Proteina',
                                      (    SELECT    COALESCE(ROUND(SUM((MB_Alimento.Gordura/MB_Alimento.Dose) * MB_AlimentoSessao.Dose), 1), 0)

                                             FROM    MB_Alimento
                                       INNER JOIN    MB_AlimentoSessao  ON MB_Alimento.Id                      = MB_AlimentoSessao.AlimentoId
                                       INNER JOIN    MB_SessaoAlimentar ON MB_AlimentoSessao.SessaoAlimentarId = MB_SessaoAlimentar.Id

                                            WHERE    MB_SessaoAlimentar.PlanoAlimentarId = MB_PlanoAlimentar.Id) AS 'SUM_Gordura'

                              FROM    MB_PlanoAlimentar

                             WHERE    UsuarioCriador = @UserId

                          ORDER BY    Nome ASC;

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@UserId", userId);

                        using (MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader())
                        {
                            List<PlanoAlimentar> recordList = new List<PlanoAlimentar>();

                            while (mySqlDataReader.Read())
                            {
                                recordList.Add(new PlanoAlimentar
                                {
                                    Id = mySqlDataReader["Id"].ToString(),
                                    Nome = mySqlDataReader["Nome"].ToString(),
                                    Descricao = mySqlDataReader["Descricao"].ToString(),
                                    Caloria = decimal.Parse(mySqlDataReader["SUM_Caloria"].ToString()),
                                    Carboidrato = decimal.Parse(mySqlDataReader["SUM_Carboidrato"].ToString()),
                                    Proteina = decimal.Parse(mySqlDataReader["SUM_Proteina"].ToString()),
                                    Gordura = decimal.Parse(mySqlDataReader["SUM_Gordura"].ToString())
                                });
                            }

                            return recordList;
                        }
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        public bool NomeExists(string nome, string userId, string planoAlimentarId)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        SELECT    Id

                          FROM    MB_PlanoAlimentar

                         WHERE    Nome           =  @Nome
                           AND    UsuarioCriador =  @UserId
                           AND    Id             <> @PlanoAlimentarId;

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@Nome", nome);
                        mySqlCommand.Parameters.AddWithValue("@UserId", userId);
                        mySqlCommand.Parameters.AddWithValue("@PlanoAlimentarId", planoAlimentarId);

                        using (MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader())
                        {
                            return mySqlDataReader.HasRows;
                        }
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        public PlanoAlimentar GetPlanoAlimentarRecordById(string planoAlimentarId)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        SELECT    Nome,
                                  Descricao

                          FROM    MB_PlanoAlimentar

                         WHERE    Id = @PlanoAlimentarId;

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@PlanoAlimentarId", planoAlimentarId);

                        using (MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader())
                        {
                            mySqlDataReader.Read();

                            return new PlanoAlimentar
                            {
                                Nome = mySqlDataReader["Nome"].ToString(),
                                Descricao = mySqlDataReader["Descricao"].ToString()
                            };
                        }
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        public PlanoAlimentar GetPlanoSessaoAlimentarById(string planoAlimentarId)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        SELECT    Nome,
                                  Descricao

                          FROM    MB_PlanoAlimentar

                         WHERE    Id = @PlanoAlimentarId;

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@PlanoAlimentarId", planoAlimentarId);

                        using (MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader())
                        {
                            mySqlDataReader.Read();

                            SessaoAlimentarRN sessaoAlimentarRN = new SessaoAlimentarRN();
                            List<SessaoAlimentar> sessaoAlimentarList = sessaoAlimentarRN.GetSessaoAlimentarListByPlanoAlimentar(planoAlimentarId);

                            return new PlanoAlimentar
                            {
                                Nome = mySqlDataReader["Nome"].ToString(),
                                Descricao = mySqlDataReader["Descricao"].ToString(),
                                Caloria = sessaoAlimentarList.Sum(e => e.Caloria),
                                Carboidrato = sessaoAlimentarList.Sum(e => e.Carboidrato),
                                Proteina = sessaoAlimentarList.Sum(e => e.Proteina),
                                Gordura = sessaoAlimentarList.Sum(e => e.Gordura),
                                SessaoAlimentarList = sessaoAlimentarList
                            };
                        }
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        #endregion Get

        #region Create

        public string CreatePlanoAlimentarRecord(PlanoAlimentar record)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        INSERT INTO MB_PlanoAlimentar
                            (Id
                            ,Nome
                            ,Descricao
                            ,UsuarioCriador)

                        VALUES
                            (@Id
                            ,@Nome
                            ,@Descricao
                            ,@UsuarioCriador);

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        string planoAlimentarId = Guid.NewGuid().ToString();

                        mySqlCommand.Parameters.AddWithValue("@Id", planoAlimentarId);
                        mySqlCommand.Parameters.AddWithValue("@Nome", record.Nome);
                        mySqlCommand.Parameters.AddWithValue("@Descricao", record.Descricao);
                        mySqlCommand.Parameters.AddWithValue("@UsuarioCriador", record.UsuarioCriador);

                        mySqlCommand.ExecuteNonQuery();

                        return planoAlimentarId;
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        #endregion Create

        #region Update

        public void UpdatePlanoAlimentarRecordById(PlanoAlimentar record)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        UPDATE    MB_PlanoAlimentar

                           SET    Nome      = @Nome,
                                  Descricao = @Descricao

                         WHERE    Id = @PlanoAlimentarId;

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@PlanoAlimentarId", record.Id);
                        mySqlCommand.Parameters.AddWithValue("@Nome", record.Nome);
                        mySqlCommand.Parameters.AddWithValue("@Descricao", record.Descricao);

                        mySqlCommand.ExecuteNonQuery();
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        #endregion Update

        #region Delete

        public void DeletePlanoAlimentarRecord(string planoAlimentarId)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        DELETE FROM    MB_AlimentoSessao

                              WHERE    SessaoAlimentarId IN (SELECT Id FROM MB_SessaoAlimentar WHERE PlanoAlimentarId = @PlanoAlimentarId);



                        DELETE FROM    MB_SessaoAlimentar

                              WHERE    PlanoAlimentarId = @PlanoAlimentarId;



                        DELETE FROM    MB_PlanoAlimentar

                              WHERE    Id = @PlanoAlimentarId;

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@PlanoAlimentarId", planoAlimentarId);

                        mySqlCommand.ExecuteNonQuery();
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        #endregion Delete

        #endregion Public Methods

    }
}
