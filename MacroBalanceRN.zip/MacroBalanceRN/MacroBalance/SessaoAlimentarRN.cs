﻿using MacroBalanceRN.Models;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MacroBalanceRN.MacroBalance
{
    public class SessaoAlimentarRN
    {

        #region Connection

        private readonly string _Connection = "server=localhost; database=macrobalance; username=root; password=;";

        #endregion Connection

        #region Public Methods

        #region Get

        public List<SessaoAlimentar> GetSessaoAlimentarListByPlanoAlimentar(string planoAlimentarId)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                          SELECT    Id,
                                    Nome

                            FROM    MB_SessaoAlimentar

                           WHERE    PlanoAlimentarId = @PlanoAlimentarId

                        ORDER BY    Ordem ASC;

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@PlanoAlimentarId", planoAlimentarId);

                        using (MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader())
                        {
                            List<SessaoAlimentar> recordList = new List<SessaoAlimentar>();

                            while (mySqlDataReader.Read())
                            {
                                string sessaoAlimentarId = mySqlDataReader["Id"].ToString();

                                AlimentoSessaoRN alimentoSessaoRN = new AlimentoSessaoRN();
                                List<AlimentoSessao> alimentoSessaoList = alimentoSessaoRN.GetAlimentoSessaoListBySessaoAlimentar(sessaoAlimentarId);

                                recordList.Add(new SessaoAlimentar
                                {
                                    Id = sessaoAlimentarId,
                                    Nome = mySqlDataReader["Nome"].ToString(),
                                    Caloria = alimentoSessaoList.Sum(e => e.Caloria),
                                    Carboidrato = alimentoSessaoList.Sum(e => e.Carboidrato),
                                    Proteina = alimentoSessaoList.Sum(e => e.Proteina),
                                    Gordura = alimentoSessaoList.Sum(e => e.Gordura),
                                    AlimentoSessaoList = alimentoSessaoList
                                });
                            }

                            return recordList;
                        }
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        public string GetSessaoAlimentarRecordById(string sessaoAlimentarId)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        SELECT    Nome

                          FROM    MB_SessaoAlimentar

                         WHERE    Id = @SessaoAlimentarId;

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@SessaoAlimentarId", sessaoAlimentarId);

                        using (MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader())
                        {
                            mySqlDataReader.Read();

                            return mySqlDataReader["Nome"].ToString();
                        }
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        #endregion Get

        #region Create

        public void CreateSessaoAlimentarRecord(string nome, string planoAlimentarId)
        {
            try
            {
                int ordem = 0;

                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        SELECT    COALESCE(COUNT(Id), 0) + 1 AS 'COUNT'

                          FROM    MB_SessaoAlimentar

                         WHERE    PlanoAlimentarId = @PlanoAlimentarId;

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@PlanoAlimentarId", planoAlimentarId);

                        using (MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader())
                        {
                            mySqlDataReader.Read();

                            ordem = Convert.ToInt32(mySqlDataReader["COUNT"]);
                        }
                    }
                }

                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        INSERT INTO MB_SessaoAlimentar
                            (Id
                            ,Nome
                            ,Ordem
                            ,PlanoAlimentarId)

                        VALUES
                            (@Id
                            ,@Nome
                            ,@Ordem
                            ,@PlanoAlimentarId);

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        string sessaoAlimentarId = Guid.NewGuid().ToString();

                        mySqlCommand.Parameters.AddWithValue("@Id", sessaoAlimentarId);
                        mySqlCommand.Parameters.AddWithValue("@Nome", nome);
                        mySqlCommand.Parameters.AddWithValue("@PlanoAlimentarId", planoAlimentarId);
                        mySqlCommand.Parameters.AddWithValue("@ordem", ordem);

                        mySqlCommand.ExecuteNonQuery();
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        #endregion Create

        #region Update

        public void UpdateSessaoAlimentarRecordById(string nome, string sessaoAlimentarId)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        UPDATE    MB_SessaoAlimentar

                           SET    Nome = @Nome

                         WHERE    Id = @Id;

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@Id", sessaoAlimentarId);
                        mySqlCommand.Parameters.AddWithValue("@Nome", nome);

                        mySqlCommand.ExecuteNonQuery();
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        #endregion Update

        #region Delete

        public void DeleteSessaoAlimentarRecordById(string sessaoAlimentarId)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        DELETE FROM    MB_AlimentoSessao

                              WHERE    SessaoAlimentarId = @SessaoAlimentarId;



                        DELETE FROM    MB_SessaoAlimentar

                              WHERE    Id = @SessaoAlimentarId;

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@SessaoAlimentarId", sessaoAlimentarId);

                        mySqlCommand.ExecuteNonQuery();
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        #endregion Delete

        #endregion Public Methods

    }
}
