﻿using MacroBalanceRN.Models;
using MySql.Data.MySqlClient;
using System;

namespace MacroBalanceRN.MacroBalance
{
    public class UnidadeMedidaRN
    {

        #region Connection

        private readonly string _Connection = "server=localhost; database=macrobalance; username=root; password=;";

        #endregion Connection

        #region Public Methods

        #region Get

        public bool NomeExists(string nome, string userId)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        SELECT    Id

                          FROM    MB_UnidadeMedida

                         WHERE    Nome           = @Nome
                           AND    UsuarioCriador = @UserId;

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@Nome", nome);
                        mySqlCommand.Parameters.AddWithValue("@UserId", userId);

                        using (MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader())
                        {
                            return mySqlDataReader.HasRows;
                        }
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        public bool SimboloExists(string simbolo, string userId)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        SELECT    Id

                          FROM    MB_UnidadeMedida

                         WHERE    BINARY Simbolo = @Simbolo
                           AND    UsuarioCriador = @UserId;

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@Simbolo", simbolo);
                        mySqlCommand.Parameters.AddWithValue("@UserId", userId);

                        using (MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader())
                        {
                            return mySqlDataReader.HasRows;
                        }
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        #endregion Get

        #region Create

        public string CreateUnidadeMedidaRecord(UnidadeMedida record)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        INSERT INTO MB_UnidadeMedida
                            (Id
                            ,Nome
                            ,Simbolo
                            ,UsuarioCriador)

                        VALUES
                            (@Id
                            ,@Nome
                            ,@Simbolo
                            ,@UsuarioCriador)

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        string unidadeMedidaId = Guid.NewGuid().ToString();

                        mySqlCommand.Parameters.AddWithValue("@Id", unidadeMedidaId);
                        mySqlCommand.Parameters.AddWithValue("@Nome", record.Nome);
                        mySqlCommand.Parameters.AddWithValue("@Simbolo", record.Simbolo);
                        mySqlCommand.Parameters.AddWithValue("@UsuarioCriador", record.UsuarioCriador);

                        mySqlCommand.ExecuteNonQuery();

                        return unidadeMedidaId;
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        #endregion Create

        #endregion Public Methods

    }
}
