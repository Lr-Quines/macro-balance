﻿using MacroBalanceRN.Models;
using Microsoft.IdentityModel.Tokens;
using MySql.Data.MySqlClient;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace MacroBalanceRN.MacroBalance
{
    public class AuthRN
    {

        #region Connection

        private readonly string _Connection = "server=localhost; database=macrobalance; username=root; password=;";

        private readonly string _SecretKey = "8rd1Ps9rs/QVCkLwwDDnoqZAlApe0duM28KzLphF/GHF9x08nwBG4iJmuwLtZOMC";

        #endregion Connection

        #region Public Methods

        public void SignIn(string password, string usernameEmail, out bool isSuccess, out string userId, out string username)
        {
            try
            {
                isSuccess = false;
                userId = string.Empty;
                username = string.Empty;

                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        SELECT    Id,
                                  Username,
                                  Password

                          FROM    MB_User

                         WHERE    (Username = @UsernameEmail OR Email = @UsernameEmail);

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@UsernameEmail", usernameEmail);

                        using (MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader())
                        {
                            if (mySqlDataReader.Read())
                            {
                                userId = mySqlDataReader["Id"].ToString();
                                username = mySqlDataReader["Username"].ToString();
                                string userPassword = mySqlDataReader["Password"].ToString();

                                isSuccess = HashPassword(password, userId) == userPassword; // USUÁRIO DIGITOU A SENHA CORRETAMENTE ???
                            }
                        }
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        public string SignUp(User user)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        INSERT INTO MB_User
                            (Id
                            ,Username
                            ,Password
                            ,Email)

                        VALUES
                            (@Id
                            ,@Username
                            ,@Password
                            ,@Email)

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        string userId = Guid.NewGuid().ToString();
                        string password = HashPassword(user.Password, userId);

                        mySqlCommand.Parameters.AddWithValue("@Id", userId);
                        mySqlCommand.Parameters.AddWithValue("@Username", user.Username);
                        mySqlCommand.Parameters.AddWithValue("@Password", password);
                        mySqlCommand.Parameters.AddWithValue("@Email", user.Email);

                        mySqlCommand.ExecuteNonQuery();

                        return userId;
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        public bool UsernameExists(string username)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        SELECT    Id

                          FROM    MB_User

                         WHERE    Username = @Username;

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@Username", username);

                        using (MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader())
                        {
                            return mySqlDataReader.HasRows;
                        }
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        public bool EmailExists(string email)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(this._Connection))
                {
                    mySqlConnection.Open();

                    string command = @"

                        SELECT    Id

                          FROM    MB_User

                         WHERE    Email = @Email;

                    ";

                    using (MySqlCommand mySqlCommand = new MySqlCommand(command, mySqlConnection))
                    {
                        mySqlCommand.Parameters.AddWithValue("@Email", email);

                        using (MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader())
                        {
                            return mySqlDataReader.HasRows;
                        }
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro no banco de dados: {ex.Message}");
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        public string GetToken(string username)
        {
            SymmetricSecurityKey symmetricSecurityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(this._SecretKey));
            SigningCredentials credentials = new SigningCredentials(symmetricSecurityKey, SecurityAlgorithms.HmacSha256);

            Claim[] claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, username),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString())
            };

            JwtSecurityToken jwtSecurityToken = new JwtSecurityToken(
                claims: claims,
                expires: DateTime.MaxValue,
                signingCredentials: credentials
            );

            return new JwtSecurityTokenHandler().WriteToken(jwtSecurityToken);
        }

        #endregion Public Methods

        #region Private Methods

        private static string HashPassword(string password, string userId)
        {
            // Concatena a senha e o ID do usuário
            string combinedPassword = password + userId.ToString();

            using (SHA512 sha512 = SHA512.Create())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(combinedPassword);
                byte[] hash = sha512.ComputeHash(bytes);

                // Converte o hash para uma string hexadecimal
                StringBuilder result = new StringBuilder();
                foreach (byte b in hash)
                {
                    result.Append(b.ToString("x2"));
                }

                return result.ToString();
            }
        }

        #endregion Private Methods
    }
}
